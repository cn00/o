## ILoaderについて

ILoaderは、アセットバンドルやそれ以外のPNGやwavなどのリソースを
ロードするインターフェイスです。
以下の2つのAPIを持っています。

- PreDownload
  素材のダウンロードのみを行います。

- LoadFromCacheOrDownload
  素材のロード、ダウンロードを行います。


### 各ロード対象とIloaderに関する対応表
| 素材                              | Caching Type | 対応Loader             | 対応IF                                                                                                                                              | Network Architecture                                                         |
|-----------------------------------|--------------|------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------|
| AssetBundle                       | Unity        | UnityAssetBundleLoader | LoadFromCacheOrDownload PreDownload                                                                                                                 | DownloadHandlerAssetBundle                                                   |
|                                   | Octo         | OctoAssetBundleLoader  | LoadFromCacheOrDownload PreDownload                                                                                                                 | UnityWebRequest -> AssetBundle.LoadFromFile ※PreDownloadはLoadFromFileしない |
|                                   | キャッシュしない         | UnityAssetBundleLoader  OctoAssetBundleLoader  | LoadFromDownload                                                                                                   | UnityWebRequest |
| string Texture2D AudioClip byte[] | Unity        | 非対応                 | 非対応                                                                                                                                              | 非対応                                                                       |
|                                   | Octo         | OctoResourceLoader     | LoadFromCacheOrDownload(btye[]) LoadFromCacheOrDownload(string) LoadFromCacheOrDownload(Texture2D)  LoadFromCacheOrDownload(AudioClip)  PreDownload | UnityWebRequest -> WWW ※PreDownloadはWWWしない                               |
| byte[]                            | キャッシュしない      | OctoManager | LoadResourceFromDownload | UnityWebRequest                               |
