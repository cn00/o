# DB

オクトでは、プロジェクトで使われている全リソースの情報を各端末に保存しています。
この情報のことを、オクトではDBと呼んでいます。
ローカルにあるDBはオクトの初期化時に読み込まれ、APIの `StartDbUpdate` を呼ぶことでローカルDBは最新の状態になります。

DBは世代管理されており、DB更新時も更新されたリソースに関する情報のみを上書きする差分更新を採用しています。
さらに通信とファイルの読み書きに関しては、`Protocol Buffers` を採用していますので、`JSON` と比較して扱うサイズが大幅に減少しています。
これにより、通信量・DBのサイズ・処理時間ともに最小限に留めることができます。

## ファイル構成

| 環境         | DBのパス |
| -----------  | -------- |
| エディタ     | {プロジェクトルート}/app_root/octo/{OctoSettings.appId}/{OctoSettings.version}/octocacheevai             |
| iOS          | {Application.temporaryCachePath}/app_root/octo/{OctoSettings.appId}/{OctoSettings.version}/octocacheevai |
| Android      | {Application.temporaryCachePath}/app_root/octo/{OctoSettings.appId}/{OctoSettings.version}/octocacheevai |

### Why app_root?

アメーバゲームの中で使われている共通ライブラリである `cauntiy-common` のアプリデータの保存先が `app_root` となっていることに由来しています。
オクトのメインターゲットもアメーバゲームであるため、保存先を踏襲しています。
もし上記の共通ライブラリを使っていない場合、`app_root` をgitignoreに追加して下さい。

## ローカルDBの暗号化

前述のようにDBは `Protocol Buffers` で保存されているため、DBをエディタで開いても人間が読みやすいようにはなっていません。
しかしながら文字列などが暗号化されているわけではないので、リソースの名前やURLなどといった情報は読み取ることができます。
もしDBの情報を僅かにでもエンドユーザーに知られたくない場合、`OctoSettings.clientSecretKey` に任意の文字列を与えることで、ローカルDBをAESによって暗号化することができます。

### 暗号化の注意点

一度暗号化した後、`clientSecretKey` の文字列を違う値にするとDBが読み込めなくなってしまいます。
また現状はデフォルト生で保存していますが、途中から暗号化を利用した時に生のDBを読み込んで、それを暗号化して保存し直すというスムーズな移行ができないので、
暗号化が必要な場合早めに設定することを推奨します。
もし途中で鍵を設定・変更する場合、必ず `app_root/octo` をフォルダごと削除して下さい。

## 関連するAPI

### OctoManager.IsLatestDb(Action<bool, int, DownloadError> onComplete)

現在のデータベースが最新のrevisionかどうかをサーバーに問い合わせます。

通信完了時にonCompleteで設定したコールバックが呼ばれます。
コールバックの引数は順に、最新かどうか、最新のrevision、通信エラーを表します。
また通信エラーやサーバーからの応答が異常だった場合、最新かどうかは `true` を返します。

