# BulkDownloader
BulkDownloaderは、一括ダウンロードを補助するための機能です。
Octo標準の機能をラップして、AssetBundle/Resourcesのダウンロードをするための準備からエラーハンドリングまでをサポートします。

## 実装

### 全体の流れ

1. BulkDownloaderを作成する
2. ダウンロードしたい物をガンガン追加する
3. キャッシュ済みの物を消すAPIを呼ぶ
4. 必要に応じて、ダウンロードすべき物として残ったものの、個数・サイズなどを取得する
5. 必要に応じて、各種コールバックイベントを登録する
6. ダウンロードAPIを呼ぶ
7. ダウンロード完了まで待機する
8. エラーハンドリングを行う
9. 必要に応じて、リトライAPIを呼ぶ

### BulkDownloaderの作成

BulkDownloaderは、 `Octo.BulkDownloaderFactory` を通して作成します。
3種類のBulkDownloaderを作成できます。

1. CreateAssetBundle: AssetBundle専用のDownloaderです。このDownloaderではResourcesのダウンロードができません。
2. CreateResources: Resources専用のDownloaderです。このDownloaderではAssetBundleのダウンロードができません。
3. CreateMix: AssetBundle/Resourcesを一緒に扱えるDownloaderです。APIに依ってはAssetBundle→Resourcesの順で名前解決をするため、Resourcesが多いときはパフォーマンスが悪化する可能性があります。

基本的には種類が決まっている場合は専用のDownloaderを、種類が決まっていない/混在する場合はMixを選んで下さい。

### ダウンロードするものを追加する

どのDownloaderにもAddとAddByTagというAPIが用意されています。
Addは名前指定で追加できます。
AddByTagを使うと、そのタグが含まれている物を一括で追加できます。
またMixの場合、これらのAPIは内部でAssetBundle→Resourcesの順で名前解決を行います。

どちらのAPIにも、単品/複数版があります。
またAssetBundle用に、依存しているものも同時に追加するかどうかを引数で選べます。

またMix専用でAddAssetBundlesとAddResourcesが用意されています。
これはMixの名前解決順の仕様に起因したパフォーマンス低下を回避するためのAPIです。
ダウンロードするものがどちらか確定している場合は、こちらを使用して下さい。

### キャッシュ済みの物を消す

Addが完了したら、RemoveLatestCachedを呼んで下さい。
呼ばなくてもダウンロード自体はキャッシュ済みのものに対しては行われないですが、次の個数や総ファイルサイズなどの計算に影響があります。

### 個数・総ファイルサイズを取得する

UI表示用やログ、進捗管理などのために以下のプロパティ・メソッドが使用可能です。

- Count: 個数
- GetTotalBytes(): 総ファイルサイズ

### コールバックイベントの登録

UI表示用やログ、進捗管理などのために以下のコールバックイベントが登録可能です。

- OnCompleteDownloadTask: 個別のダウンロードが完了した際に呼ばれる
- OnCompleteAllDownloadTask: 全てのダウンロードが完了した際に呼ばれる

### ダウンロードAPIを呼ぶ

`DownloadAll()` を呼ぶと、実際のダウンロードが始まります

### ダウンロード完了の待機

コルーチンの場合、 `yield return BulkDownloader.WaitForTaskComplete();` でダウンロード完了を待機できます。

また進捗をログに出すなど毎フレーム処理を挟みたい場合、 `IsTaskCompleted` が `true` になるまで待機することもできます。
進捗の表示には、以下のプロパティが使えます。

- TaskCompletedCount: ダウンロードが完了した個数（エラーがあったものを含む）
- DownloadedCount: ダウンロードが成功した個数
- DownloadedBytes: ダウンロードが成功した総ファイルサイズ
- ProgressCount: ダウンロードが成功した個数ベースの進捗割合
- ProgressBytes: ダウンロードが成功した総ファイルサイズベースの進捗割合
- IsCompleted: 全てのダウンロードに成功したかどうか


### エラーハンドリング

もしダウンロード時に1つ以上のエラーが有った場合、 `IsError` プロパティが `true` になります。
その際、最後に発生したエラーを `LastError` プロパティより取得できます。 （全てのエラーを取得することは現状できません）
エラー内容に応じて、リトライする、ダイアログを出すなどをして下さい。


### リトライ

エラーがあったものをそのままリトライするためには、 `RetryErrorDownload()` を呼んで下さい。
これを呼ぶと、 `IsError` プロパティなどのエラー情報はリセットされ、再びダウンロードが実行されます。


## サンプル

```cs
var bulkDownloader = Octo.BulkDownloaderFactory.CreateMix(); // AssetBundle/Resources混合のダウンローダー
bulkDownloader.Add(names.GetRange(index, len), withDeps: false); // AssetBundleとResources問わずぶっこむ
bulkDownloader.RemoveLatestCached(); // 既にキャッシュ済みを除外する

if (bulkDownloader.Count == 0) // 全てキャッシュ済みなら何もしない
{
    return;
}

var totalBytes = bulkDownloader.GetTotalBytes();
Debug.LogFormat("Download Count={0}, size={1} bytes", bulkDownloader.Count, totalBytes);
bulkDownloader.OnCompleteDownloadTask += (name, err) =>
{
    if (err != null)
    {
        Debug.LogError(err.ToString());
        return;
    }

    Debug.LogFormat("[{1}/{2}] Download completed: name={0}, downloaded={3} bytes", name, bulkDownloader.DownloadedCount, bulkDownloader.Count, bulkDownloader.DownloadedBytes);
};
bulkDownloader.OnCompleteAllDownloadTask += () =>
{
    Debug.LogFormat("Bulk download completed: last error={0}", bulkDownloader.LastError);
};
bulkDownloader.DownloadAll();
// 単純に待つ
yield return bulkDownloader.WaitForTaskComplete();

// 毎フレーム進捗をログに出しながら待つパターン
// while (bulkDownloader.IsTaskCompleted == false)
// {
//     Debug.LogFormat("Download progress: bytes={0}/{1}", bulkDownloader.DownloadedBytes, totalBytes);
//     yield return null;
// }

// エラーが無くなるまでリトライ
while (bulkDownloader.IsError == true)
{
    yield return new WaitForSeconds(1f);
    bulkDownloader.RetryErrorDownload();
    yield return bulkDownloader.WaitForTaskComplete();
}
```
