# Changelog

### v2.8.0 - 2020/08/25

- ユーザーキャッシュ機能を追加
 - 詳細は `Docs/UserCache.md` を参照してください
- awaitを行えるメソッドを追加 
- Unity2019以降で警告が出ないように

### v2.7.0 - 2020/08/18

- リストAPIを暗号化して通信できる機能を追加
  - 対応したサーバーが必要
- AssetKeeperにアセット名を指定しないAPIを追加
- タグ関連処理のパフォーマンス改善
- アンロード関連処理のパフォーマンス改善

### v2.6.6 - 2020/06/12

- v2.6.5でエンバグした、エディタでダウンロード時にエラーが出る可能性がある問題を修正
- iOS/Android実機でダウンロード中に機内モードに入れても全てのダウンロードリクエストが即座にエラーにならない問題を修正

### v2.6.5 - 2020/05/28

- Unityエディタ専用にAssetBundle内部のアセット一覧を取得する機能を追加
  - サーバー側の対応と、アップロード済みのAssetBundleの再アップロードが必要です
- 軽微なメモリリークの可能性があるのを修正
- AssetKeeperでロードが競合した時にキャンセルエラーが出ない場合がある問題を修正
- 内部のキャッシュ管理システムで排他制御が甘くて極稀に競合する可能性がある問題を修正

### v2.6.4 - 2020/04/09

- BulkDownloaderにデバッグ用にダウンロードする物の名前とサイズを返すGetAllItems()を追加

### v2.6.3 - 2020/02/27

- AssetBundleのアンロード処理時に稀にAssertに引っかかるバグを修正
- AssetKeeperのOnDestroyをvirtualに変更
- AssetKeeperを継承したクラスでもインスペクターが表示されるように
- deprecated: SetupHelperのdomain reload対応が漏れていたのを修正

### v2.6.2 - 2020/02/10

- EditorHelperを通してAssetBundleをロードする時に、AssetBundleEditorLoadInterceptorを通して独自処理を追加できるように

### v2.6.1 - 2020/02/03

- BulkDownloaderのMix版使用時に、片方がCounts=0の場合ワーニングが出てしまうのを修正
- BulkDownloaderでDownloadAll前にDownloadedBytesを呼んでもNullRefExpが出ないように修正

### v2.6.0 - 2019/11/26

#### 新規

- AssetKeeper：第二世代のAssetLoader；よりシンプルに使えるように
- エラー：ロードされているAssetBundleの更新をダウンロードしようとした時の専用エラー `octo.io.using_old_cache` を追加
- AssetLoader：キャッシュしないオンメモリ版の機能を追加
- BulkDownloader： 空ダウンロードや多重ダウンロードの予防機構を追加
- OctoManager：強制アンロード機能を追加
- Unity Package Managerに対応
- Unity 2019.3以降のdomain reload無効化時に正しく動作するように

#### 変更

- OctoのメニューをTools配下に移動
- ダウンロード進捗コールバックを通信完了後にも呼ばれることを保証するように

#### バグ修正

- iOS実機でENOSPCが発生してもディスクフルではなくunknownエラーになっていた問題を修正
- Androidの一部実機でディスクフル判定がすり抜けていた問題を修正
- 通信内容をデシリアライズする際に稀に発生していたEndOfStreamExceptionをキャッチするように
- BulkDownloader：Concurrent modificationのバグ修正
- ロード処理完了後の無駄な1フレーム待機を改善
- エディタ拡張：ランタイムでロード済みのAssetBundleをロードできない問題を修正
- エディタ拡張：AssetDatabaseでアセット名を指定したロードができない問題を修正
- エディタ拡張：シェーダーの再アタッチでmaterialのレンダーキューが書き換わる問題を修正
- Unity 2017.1以下でコンパイルエラーになる問題を修正
- Unity 2019以降で出るエディタの構文解析エラーに対応
- 最新のFastAESと併用時にAndroidで上手く暗号化できなかった問題を修正

### v2.5.1 - 2019/04/19

- Unity 2019以降のAndroidでコンパイルエラーが出てしまう問題の修正
- AssetLoaderのインスタンスでAssetLoaderExtensionのメソッドを使用時に、AssetLoaderが増えてしまう問題の修正

### v2.5.0 - 2019/04/09
iOS向けのAssetBundleのアプリ埋め込み機能＋AEROのフィードバック

- iOS向けのAssetBundleのアプリ埋め込み機能 `AppCaching` を追加
  - `PostProcessBuild` にて、 `Octo.Editor.BuildSupport.AddAssetsToXcode` を呼ぶと、AssetBundleをダウンロードしてXcodeプロジェクトの中に配置します
- BulkDownloaderに任意条件で削除できる `RemoveWhere` 機能を追加
- EditorHelperにアセット名を指定してロードする処理を追加
- Android実機で通信がタイムアウトしたときに例外が出る問題を修正
- Android実機で通信完了直後に稀に裏で例外が出る可能性がある問題を修正
- キャッシュの非同期ウォームアップ中に、サイズ取得をしようとしたり存在を確認しようとしたりすると、稀に誤った判定をしてしまう場合がある問題を修正
- キャッシュの（自動）削除が働く時に、例外が出る場合があるのを修正
- `OCTO_FAST_AES` を使っている場合、Windowsエディタ上でFastAESが誤って有効になる問題を修正


### v2.4.0 - 2018/09/21

- 一括ダウンロードする際にファイルサイズ管理や進捗管理を補助するBulkDownloaderを導入
- ErrorにNameプロパティを追加（エラーの原因になったアセット名などが入る）
- DownloadErrorInterceptorの引数にリトライ回数を追加
  - 破壊的な変更なので、使っている場合は引数を追加してください
- GetTotal*SizeToDownloadの引数の型をIListからIEnumerableに変更
- メモリアロケーションの改善
- 特定のUnity環境で、アセットバンドル名に全角文字が含まれていた場合にフリーズするワークアラウンドを導入

### v2.3.3 - 2018/08/22

- WebGLでコンパイルエラーになる問題を修正
- OctoManager.DatabaseにダウンロードURLを取得する機能を追加
  - メディアのストリーミングなどの目的のための機能なので、通常は使用しない
  - GetAssetBundleDownloadUrl(name)
  - GetResourcesDownloadUrl(name)

### v2.3.2 - 2018/08/16

- AssetLoaderのリセットでコルーチンが停止しない問題を修正
- iOSでダウンロード中に通信エラーが発生した場合、クラッシュ/フリーズが発生する可能性がある問題を修正
- Unity 2017.2以前でFastAES導入時に、AssemblyDefinition未対応のためにコンパイルエラーになる問題を修正
- Unity 5.3, 5.4でサポートされていないAPIを使用していた問題を修正
- 一部の内部処理を高速化＆省メモリ化

### v2.3.1 - 2018/08/07

- v2.3.0で導入したAssembly Definitionに不備があり、アプリビルド時にコンパイルエラーになるのを修正
- 内蔵しているFastAESのインターフェイス部分をv0.1.5に更新

### v2.3.0 - 2018/07/26

- 初期化方法にOctoFullSettingsを使う方法導入
  - 完全にスクリプトだけで初期化できるように
  - OctoSettingsより設定項目を拡充
  - OctoSettingsよりセキュアなため、今後はこちらの初期化を推奨
- SDK本体とViewerがAssembly Defintionに対応
- AssetBundleのロード方法をカスタム指定できるように
  - `OctoManager.AssetBundleLoadInterceptor` と `AssetBundle.OnAssetBundleUnloadCompleted` にカスタム処理を設定する
- エディタ向けにAssetBundleのシェーダー再アタッチ処理をEditorHelperに追加
- UnityWebRequestでUnityバージョンによってはObsoleteなプロパティを使っていたのを修正
- 古いキャッシュが自動削除される際に、内部チェックに引っかかって警告が出る可能性があったのを修正

### v2.2.0 - 2018/07/03

- AssetLoaderの拡張機能追加
- AssetLoaderでのタイプエラーチェックを行わないように変更
- AssetLoaderでリソース読み込み時にエラーが出てしまう問題を修正
- AssetDatabaseOperatorで未サポートだったAPIをサポートするように修正
- エディタ上でアセットをロードするためのヘルパーを追加
- Unity2017.2から非推奨になったAPIを使用しないように

### v2.1.4 - 2018/05/17

- AssetLoaderの初期化を行えるResetメソッドを追加

### v2.1.3 - 2018/05/08

- AssetLoader経由でResources.Loadをおこなった時、2回目以降のロードでエラーが出てしまう問題の修正

### v2.1.2 - 2018/04/26

- AssetLoaderへAssetBundleをロードするのみのAPIを追加

### v2.1.1 - 2018/04/25

- AssetLoaderからIsStreamedSceneAssetBundleプロパティを取得できるように修正

### v2.1.0 - 2018/04/11

- AssetLoaderにResoucesフォルダから読み込む機能を追加

### v2.0.4 - 2018/04/09

- ファイルダウンロードURLが正しくない場合がある問題の修正
  - バージョンアップ時、一度だけローカルDBの削除が行われます
- AssetBundleOperatorにScene用のAPIを追加
- CachingTypeがUnityDefaultの場合、Abort時にエラーが出てしまう問題の修正

### v2.0.3 - 2018/03/27

- .NET 4.6の環境でダウンロード時、エラーが出てしまう可能性がある問題の修正

### v2.0.2 - 2018/03/13

- Webglプラットフォームだとコンパイルエラーが出てしまう問題の修正

### v2.0.1 - 2018/03/02

- Unity2017以降だとコンパイルエラーが出てしまう問題の修正

### v2.0.0 - 2018/02/15

- ファイルダウンロード時、URLを取得するAPIを使用しないように変更
  - バージョンアップ時、一度だけローカルDBの削除が行われます

### v1.5.2 - 2017/11/27

- サイズ取得メソッドがループしてしまう問題の修正
  - OctoManager.Database.GetTotalAssetBundlesSize(params string[] names)
  - OctoManager.Database.GetTotalResourcesSize(params string[] names)

### v1.5.1 - 2017/10/10

- WebGL環境で出ていたコンパイルエラーの修正
- Unity標準のキャッシングタイプでリダイレクト方式をやめてダウンロードURLを事前に取得する方式に変更
  - FireFoxでリソース・アセットバンドルをダウンロード出来ない問題の修正
  - Unity標準でのキャッシング管理は2017.1より前ではサポートされなくなりました

### v1.5.0 - 2017/09/05

- Unity 2017.1に対応
- キャッシュしないでダウンロード＆ロードするAPI追加
  - OctoManager.LoadAssetBundleFromDownload
  - OctoManager.LoadResourceFromDownload
- 実行中のメモリ使用量を大幅に削減（当社比50%以上）

### v1.4.2 - 2017/07/21

- Androidの一部機種（Galaxy系）でネイティブダウンロードがクラッシュする問題を修正

### v1.4.1 - 2017/07/06

- SetTopPriority系に、強制的に即時ロードができるimmediateExecuteフラグを追加
  - ただしダウンロードが必要な場合は即時ロードではないので、将来的に改修予定

### v1.4.0 - 2071/05/31

- Androidのファイルダウンロードをネイティブ側で完結するように
  - 速度、CPU、メモリ効率の面で改善
- キャッシュ初期化部分の流れがわかるドキュメント追加
- 自動エラー情報収集機能追加
  - 内部的に致命的なエラーが起きた時に自動でエラー情報をサーバーへ送信する仕組み
- その他細かいリファクタリング

### v1.3.1 - 2017/05/30

- v1.2.3〜v1.2.5までの変更を取り込み

### v1.3.0 - 2017/04/27

- キャッシュ削除時に、フォルダ毎削除するようにし、かつ削除自体を別スレッドでやってメインスレッドの停止時間を削減
  - 今までは本体ファイルだけ削除し、次の起動時にフォルダがお掃除されていたので初期化の時間が長くなることがあった
- 起動中に新規にダウンロードされたり、IsLatestCachedでtrueを返したものについては、お掃除の対象外とするようにした
  - 非常に稀に起きる可能性があった、使おうとしたらお掃除されていたという可能性を排除するため
- SRDebuggerの公式プラグインを別パッケージで提供
- キャッシュ内部のウォームアップスレッド（真の初期化）の状態取得・コールバック機能と、任意タイミングでのpause/resume機能を追加
- その他細かいリファクタリング

### v1.2.5 - 2017/05/25

- バックグラウンド初期化中にエラーが発生した状態でCleanCacheを行うとタイミングによってはフリーズしてしまう事がある問題を修正
    - v1.2.4より影響

### v1.2.4 - 2017/05/19

- バックグラウンド初期化開始直後に、CleanCacheをしようとするとキャッシュが消えない可能性があるのを修正

### v1.2.3 - 2017/05/18

- バックグラウンド初期化中に、キャッシュクリアをしようとするとデッドロックする可能性があるのを修正
  - v1.1.11より影響
  - 早めの更新を推奨します

### v1.2.2 - 2017/04/18

- バックグラウンド初期化中に未キャッシュのAssetBundle/Resourceに対して、キャッシュ状態を2回以上チェックしようとした時に著しくパフォーマンスが劣化する問題を修正
  - v1.1.10より影響
  - 更新を強く推奨します

### v1.2.1 - 2017/04/04

- 1.2.0より前に作られたiOSのNSURLキャッシュを、端末毎に最初の一度だけ削除するように

### v1.2.0 - 2017/03/28

- iOSのファイルダウンロードをネイティブ側で完結するように
  - 速度、CPU、メモリ効率の面で改善
  - 上記に伴い、HttpWebRequest使用のオプションを削除、及び関連ファイルの削除
- 有効期限の切れたキャッシュを自発的に消せるDeleteExpiredCaches APIをICachingに追加
  - 上記に伴い、ExpirationDelayの内部で自動的に有効期限切れを削除しないように
  - ExpirationDelayを設定している場合、挙動を同じするためには直後にDeleteExpiredCachesを呼んでください（必ず呼ぶ必要はありません）

### v1.1.12 - 2017/03/24

- iOSで、metaファイルの非同期書込の並列数を無制限から1に絞るように変更

### v1.1.11 - 2017/03/07

- Androidでinternal/external領域の両方に対応するように
  - 優先順位はinternal > external
  - 既にどちらかにある場合はそちらを使う
- DB更新中にバージョンを切り替えた時に、切り替え後のDBに差分更新を適用するバグを修正
- キャッシング内部で無駄なロックを減らした
- ロード中のAssetLoaderをDestroyした場合、OnDestroyでコールバックするように改善
- ダウンロードとロード状況を直接オーバーレイ表示するデバッグ機能を追加
  - OctoManager.Debuggerをtrueに

### v1.1.10 - 2017/01/31

- キャッシング
  - 最終使用日の書き込みを非同期化しました
  - 内部のlock戦略を最適化し、パフォーマンスを向上させました
  - ファイルサイズのフィールドをlongからintに変更し、メモリを節約しました
  - 初期化時のソート中にアセットを削除しようと問題が起こるバグを修正しました
  - キャッシュ削除後に再DLすると、最終使用日が更新されないバグを修正しました
- ドキュメント
  - 幾つかのAPIで単位がbyteであることを明記しました
  - 通信リトライの戦略に関するドキュメントを追加しました

### v1.1.9 - 2017/01/04

- キャッシング
  - バックグラウンド初期化中に例外が起きた場合、以降常にキャッシュディレクトリをチェックするように
  - バックグラウンド初期化の一部処理に安全のためロックをかけるように
  - ダウンロード後の処理でファイル操作に失敗した場合、きちんとエラーを返すように
  - バックグラウンド初期化中にAssetBundleをロードした際に、 `UnauthorizedAccessException` が出る可能性を修正
  - キャッシュ期限を使用している場合に、IsCached APIでも期限チェックをするように

### v1.1.8 - 2016/12/20

- キャッシング
  - 内部で稀に競合が発生していた、スレッドアンセーフな処理を修正
  - ダウンロードするファイルの書き込み先を、安全のため専用のディレクトリを経由して移すように変更
  - 本来ファイルが存在することを想定していない階層でファイルを見つけたら削除するように

### v1.1.7 - 2016/12/02

- キャッシュがサイズ上限に達すると、ダウンロードしようとしても自動削除が働かずにディスクフルエラーを常に返すようになっていたバグを修正
- AssetBundle名を指定する際に全角文字が来ても例外を吐かないように修正

### v1.1.6 - 2016/11/28

**本バージョンより、iOSのデフォルトの通信方式をUnityWebRequestにしています。**
#506 の通り、HttpWebRequestは通信安定性が望めないためです。
**ただし通信速度は遅くなることは間違いない** ので、どうしても速度優先したい場合は、 `OCTO_HTTP_WEBREQ` をdefineして下さい。
（ただしこれは推奨しません、 **不幸** を招きます、 **本当に不幸** です。）

#### API追加/仕様変更

- **iOSのみ使っていたHttpWebRequestを、UnityWebRequestを使うように**
- 実行時に動的に OctoManager.Downloader.MaxParallel を変更できるように
- AssetLoader: SetTopPriorityメソッド追加
- PreDownloadとLoadFromCacheOrDownload系に、リスト版のAPIを追加
- スタンドアローンのwin/macで、DB/キャッシュの保存先をexeと同じ階層に変更

#### 改善

- Android用に、oggファイルも拡張子残して保存するように（リソース）
- AssetLoader
  - 待つ必要がないのに1フレーム待ってしまう場合がある問題を修正
  - エディタ上でAssetLoaderを選択した時のインスペクタ表示で、heapを乱用しないように改善
- UnloadAssetBundleをし過ぎた場合に出力したログを、エラーログではなくワーニングに格下げ
- ダウンロード時のスレッド起床回数が低減するように改善
- コールバック時にゲーム側で例外吐いても問題ないように、octo側で例外を無視するように
- Unity 5.5向けに、DLLを.Net 2.0でビルドし直し

#### バグ修正

- 有効期限による削除機能を使っている場合、内部でforeach中に辞書操作する可能性があった問題を修正
- FastAESが有効でも、FastAESがサポートしていないプラットフォームでは使わないように修正（Windows向け）

### v1.1.5 - 2016/07/20

- ダウンロード済みのキャッシュのappId間マイグレーション機能を追加
  - 旧バージョンでappIdを切り替えたアプリのキャッシュ救済用
  - ローカルDBは救済対象外

### v1.1.4 - 2016/07/08

- 初回起動時のみiOSでダウンロードしたものがiCloudのバックアップ対象になってしまうバグを修正

### v1.1.3 - 2016/07/06

- DB構築に関係した通信APIを叩く時に、GoogleのCDNにキャッシュされるようにヘッダーを調整
  - キャッシュが効くとStartDbUpdateの応答が爆速になります

### v1.1.2 - 2016/07/05

- iOSで稀にMD5不一致エラーが出ていたバグを修正
  - Unityは何も悪くありませんでした
  - :yaki_dogeza:

### v1.1.1 - 2016/06/29

- 新機能
  - ダウンロードが必要な合計サイズを取得するAPI
    - `OctoManager.GetTotalAssetBundlesSizeToDownload`, `OctoManager.GetTotalResourcesSizeToDownload`
  - 統計機能
    - `Octo.Statistics.Network.DownloadedBytes`: API通信分含む、起動時からの総ダウンロードバイト数
    - `Octo.Statistics.Network.DownloadedContentBytes`: API通信分含まない、起動時からの総ダウンロードバイト数（AssetBundle、Resource系のみ）
    - インスペクターにも表示
  - 通信エラーのインターセプト機能
    - 通信エラーが発生した際に、コールバック前にインターセプトして、後続処理をブロックしつつスルー/リトライ/全アボートできるように
  - ダウンロードタスクの全アボート
    `OctoManager.DownloadExecutor.AbortAll`
- キャッシング
  - 保存先をOS指定の非キャッシュ領域に
    - v1.1.0の仕様変更のrevert
    - ディスクフル時の挙動が想定外だったため
  - Androidでディスクフル時のエラーコードが正しく返せていなかった問題を修正
  - メタファイルが壊れていた場合に例外を起こしていた問題を修正
  - IOExceptionのcatchが不十分だった問題を修正
- 通信
  - iOSでの通信時にバッファを使い捨てていた問題を修正
  - インターネット接続性が無い時とディスクフル時は、後続の通信を全て止めるように変更
- エラーハンドリング
  - MD5不一致のエラーコードを専用のに `octo.network.md5_checksum`
  - APIの異常応答をassertだけでなく、ちゃんとハンドリングするように修正
- AssetLoader
  - ロード中に破棄された時に様々なエラーが起こるバグを修正
- その他
  - DeleteAllUnusedを叩いた時に、削除済みワーニングが大量に出るバグを修正

### v1.1.0 - 2016/06/08

**このバージョンより、従来のローカルDBと構造の互換性がありません**
そのため初回読み込み時に内部エラーが生じますが、無視してDBの更新をすれば直ります。
リリースに向けた調整のため、ご理解とご協力をよろしくお願い致します。

- ダウンロード周り
  - 変更：iOSはUnityWebRequestをやめてHttpWebRequestに
  - 改善：通信本数削減用の新API対応（一度のダウンロードリクエストが多ければ多いほど効果大）
  - 改善：PreDownloadとLoadFromCacheOrDownloadを乱暴に混ぜても、通信を最小限に
  - 改善：無意味な自動リトライ機能削除
  - 修正：iOSでファイルの書き込みを待っていなかったのを修正
- キャッシング
  - 改善：独自キャッシングの場合、初期化完了を待つ必要がなくなりました（IsReadyが常にtrue）
  - 追加：ICachingにMarkAsUsed系のAPI追加
  - 修正：独自キャッシングでExpirationDelayを今より短く設定する時に、チェックが走らない問題を修正
- DB
  - 変更：セキュリティのため、AES暗号化時のIVを変更
  - 変更：将来的な互換性維持のため、DBの構造を改良
  - 改善：[FastAES](/ishiguro-yusuke/Unity-FastAES) 対応
    - 有効にするためには、 `OCTO_FAST_AES` を `Scripting define symbols` に追加して下さい
- 各環境でのDBとAB/リソースの保存先を調整
  - iOS/Android：OS指定のキャッシュフォルダに
  - エディタのDB：app_root/octo/pdb以下
- 削除ステータス
  - 変更：デフォルトで削除ステータスのものを使えないように
  - 改善：IsAssetBundleExists/IsResourceExistsで削除ステータスな時にwarning出さないように
- 優先度変更
  - 追加：外部から特定の名前のAB/リソースのタスクを最優先にするAPIを追加
    - ダウンロード： `OctoManager.DownloadExecutor.SetTopPriority(name)`
    - ロード： `OctoManager.LoadExecutor.SetTopPriority(name)`
  - 修正：`OctoManager.SetTopPriorityLoadingAssetBundle` が動作していなかった問題を修正
- インスペクター
  - 改善：現在処理待ちのAB/リソースのタスクの名前を表示するように
  - 改善：ラベル間に余計な余白ができていたのを修正
- その他：
  - 改善：LoadRequest.allAssts内部で、同じUnity APIを2回叩いていたのを1回に
  - 改善：通常ログを拡充
  - 追加：ライセンス

### v1.0.8 - 2016/05/11

- 追加：アセットチェックなどのための全AB名/リソース名を取得するAPIを追加（非本番用）
  - `OctoManager.Database.GetAllAssetBundleNames`, `OctoManager.Database.GetAllResourceNames`
- 追加：インスペクタ上でAssetBundle一覧のフィルタリング機能と一覧コピー機能を追加
- 修正：特定のAndroid端末で独自キャッシングが動かない問題を修正
- 修正：稀にiOSでファイル書き込み直後にファイル操作できずに例外が出てた問題を修正
- 変更：通信のデフォルトの並列数を5から2へ
- 改善：独自キャッシングで読んだAssetBundleに元の名前を命名（プロファイラ用）
- 改善：ロードとダウンロードのキューイングの仕組みを改善し、ダウンロード待ちのロード処理でブロックされないように
- 改善：独自キャッシングのAssetBundleのロードを非同期に
- 改善：独自キャッシングでのダウンロードからのファイル書き込み処理を別スレッド化
- 改善：UnityWebRequestの初期化処理でコストの高い操作を回避するように
- 改善：通信する度に接続性の確認していて、たまに初期化がスパイクしていたのを、通信が失敗したときだけ確認するように
- 改善：なるべくGCを避けるように使い回し努力

### v1.0.7 - 2016/04/21

- 修正：iOSの実機ビルドでコンパイルエラーになるバグ修正
- 修正：キャッシュ（自動）削除時に削除されたABをロードしようとするとエラーになるバグを修正
- 改善：Executor系のインスペクタ表示でキューイングされている数を表示するように

### v1.0.6 - 2016/04/20

- 追加：各種ロード・事前ダウンロード時に、ダウンロードのプログレスをコールバックするdelegateを追加
- 追加：指定した名前がDBに存在するか確認できるAPI
  - `OctoManager.IsAssetBundleExists`
  - `OctoManager.IsResourceExists`
- 追加：Executor系のプロパティを公開
  - `OctoManager.DownloadExecutor`
  - `OctoManager.LoadExecutor`
- 追加：指定したAssetBundleのロードリクエストを最優先にするAPI追加 `OctoManager.SetTopPriorityLoadingAssetBundle`
- 追加：Get*ByTag系で複数タグを全て含むような検索ができるAPIを追加
- 修正：ファイルダウンロードで自動リトライが発生したときに、IO例外が出るバグを修正
- 修正：自動削除発動時にロードされているABがあると無限ループにハマる可能性があるバグを修正
- 変更：AssetBundleの名前を内部参照時に自動的に小文字化するように変更
- 変更：一度に大量にダウンロードしようとした時に、APIサーバーとGCSを交互に叩くように変更

### v1.0.5 - 2016/04/13

- 修正：DB更新時に、リソースがAssetBundleのリストに混ざった状態で書き込まれるバグを修正
  - 発生症状：DB更新するとリソースから情報を引き出せない、Setupでエラーが出るなど
  - リソースを使っている場合は致命的なバグなので、要アップデート

### v1.0.4 - 2016/04/11

- 修正：タグの内部仕様がサーバー側と異なっていたのを修正

### v1.0.3 - 2016/04/06

- 修正：リソースを使っている場合に、DBの更新がある時に必ず失敗するバグを修正

### v1.0.2 - 2016/03/30

- 追加：ダウンロード処理とロード処理の並列数をインスペクターにグラフで描画する機能を追加
- 追加：AssetDatabaseのAssetBundleに対しても、 `OctoManager.GetAllDependencies` を取得できるように処理を追加
- 追加：以下のシンボルがある場合に、ローカルDBのアサートを有効に
  - OCTO_STRICT
  - UNITY_EDITOR
  - DEBUG
  - DEVELOPMENT_BUILD
- 修正：AssetDatabaseから読み込んだAssetBundleの時に、IAssetOperator.GetAllDependenciesが常に空を返していた問題を修正
- 修正：独自キャッシングに関する以下の問題を修正
  - ロード中のABの最終使用日を更新しようとして、IOExceptionが飛ぶ可能性を修正
  - キャッシュにダウンロード後、次の起動時にそのキャッシュが最新でも使われていなかった問題を修正
  - キャッシュへのダウンロードでファイルが壊れる可能性を修正
- 修正：IL2CPP+Development Buildの場合に、通信時にクラッシュする可能性がある問題に暫定対策を追加
- ドキュメント：ロギングに関するドキュメント [Logging.md](Docs/Logging.md) を追加

### v1.0.1 - 2016/03/24

- 修正：キャッシングタイプがUnityDefaultの時に、稀にAssetBundleのロードが完了する前にコールバックを返していたバグを修正

### v1.0.0 - 2016/03/23

- 機能追加：Octo独自キャッシュを追加しました。詳細は、[Caching.md](Docs/Caching.md)を参照ください
- 追加：`OctoManager.Setup` の引数に初期化フラグを追加（bool reset=false）
  - 従来一度Setupすると設定変更できませんでしたが、解像度変更などのために設定変更できるようにしました
- 追加：現在のローカルDBが最新のものかどうかをサーバーに問い合わせる `OctoManager.IsLatestDb` を追加
- 追加：あるAssetBundleから依存しているAssetBundle名を取得する、以下のメソッドを追加
  - `string[] OctoManager.GetAllDependenciesOfAssetBundle(string name)`
  - `string[] IAssetOperator.GetAllDependencies()`
- 修正：AssetBundleに対して `LoadAllAssetsAsync<T>` をするときに、TがUnityEngine.Object以外の場合返り値がnullになるバグを修正
- 修正：Windows環境で正しくパス生成できていなかったバグを修正
- 改善：ローカルDBの新規取得・更新処理の大幅な時間短縮

### v0.1.9 - 2016/03/09

- 修正：ロードとアンロードが衝突し、ロードした情報が消え、AssetBundleの多重ロードエラーが出るバグを修正

### v0.1.8 - 2016/03/02

- バグ：エディタ上で実行中にホットリロードが走ると、例外が発生するバグを修正
  - 例外が発生しないものの、ホットリロード自体には非対応です
- 改善：ローカルDBのソートが万が一壊れてしまった場合でも問題ないように修正
  - 定常時のパフォーマンスへの影響は最小限
- 改善：`OCTO_LOG_PERFORMANCE` 有効時のログ出力を改善、および出力箇所を増設
- パフォーマンス：ローカルDBを中心に大幅に改善、以下のAPIに影響
  - Setup
  - StartDbUpdate
- パフォーマンス：AssetBundleを管理しているMonoBehaiviourでUpdateの計算量がO(n)になっていたのをO(1)に改善
- ドキュメント：`OctoManager.CancelLoadingAssetBundle` の挙動に不足があった点を加筆修正

### v0.1.7 - 2016/02/25

- バグ：v0.1.4より導入されたUnityWebRequestに関連して、通信中にランダムにクラッシュする可能性を修正

### v0.1.6 - 2016/02/23

- 定数系の命名規則をスネークケースからキャメルケースに統一
  - この変更により、例えばエラーコード定義を使っている箇所など、一部エラーが出ることがあります。<br>
    お手数ですがご対応お願いします。<br>
    (ex.`Octo.OctoManager.VERSION → Octo.OctoManager.Version`)
- 標準状態において出力するログを抑制しました
  - 詳しいログ出力が必要な場合、 `OCTO_LOG_TRACE` もしくは `OCTO_LOG_PERFORMANCE` をscriptying define symbolsに追加して下さい
- 追加：ローカルDBのリビジョンを取得する `OctoManager.DbRevision` を追加
- 変更：IAssetOperatorのLoadAsset(Async)で引数なしの場合、内包するAssetが1つのみの場合それをロードし、複数ある場合nullを返すように変更
- バグ：ローカルDBにDELETEな保存されず、 `OctoManager.DeleteAllUnused` が機能していなかったバグを修正
- パフォーマンス：StartDbUpdateでローカルDBが最新の場合、何もしないように修正
- その他細かいパフォーマンスチューニングやリファクタリング

### v0.1.5 - 2016/02/19

- v0.1.4のエディタ向けお掃除機能が通常の環境でコンパイルエラーになる問題を修正

### v0.1.4 - 2016/02/18

- バグ修正：サーバーに問い合わせるDBのリビジョンが常に0になっているのを修正
- `OctoManager.StartDbUpdate` の初期化フラグを付けた際の挙動修正
  - キャッシュクリアされないよう修正
  - 完全初期化するよう修正（ローカルDBの内容を捨てるようにしました）
- 改善：`AssetLoader` が付いているGameObjectが非アクティブでもロードが進むように修正
- 追加：エディタメニューにクリーン系を追加
  - `Octo/Delete all local DB` : プロジェクト固有のディレクトリに保存されているローカルDBを削除する
  - `Octo/Clean Unity cache` : Unityがキャッシュしているプロジェクト固有のAssetBundleを削除する
- 追加：`AssetDatabase` 対応（UNITY_EDITOR）
  - プロジェクトのアセットに指定したAssetBundleが存在する場合は、自動的にそちらを使います。<br>
   （有効にするには、`OctoManager.EnableAssetDatabase();`を呼んで下さい）
  - サーバに上げる前のテスト用としてご利用ください。
- 改善：通信時に10秒間受信を観測しなかった場合にタイムアウトするように変更
- 追加：起動してから最後にDBを更新した時刻を `OctoManager.DbUpdateTimeAfterStartup` より取得できるように

### v0.1.3 - 2016/02/09

- GetAllLoadedAssetBundleにロードエラーのものが含まれる可能性があるのを修正
- 仕様変更：DeleteCacheで削除したかどうかをboolで返すように
- バグ修正：AssetBundleがロードされていた場合は削除しないように
- バグ修正：内部で使っているクラスと同名のクラスがglobal空間にある場合、コンパイルエラーになる可能性を修正
- API追加：DB上でDELETEになっているものを一括で削除する`DeleteAllUnused`を追加
- キャンセル機能追加：`OctoManager.CancelLoadingAssetBundle`
  - `OctoManager.LoadAssetBundle` の返り値にリクエストID追加。<br>
  `OctoManager.CancelLoadingAssetBundle` を呼ぶ際に使用して下さい。<br>
- I/O系のエラーコード追加
  - `IO_UNKNOWN_REASON` : 不明なI/Oエラー
  - `IO_STORAGE_FULL` : 書き込み先のストレージが一杯
  - `IO_PERMISSION` : R/Wのパーミッションがない

### v0.1.2 - 2016/02/03

- `AssetLoader`追加
  - 単一のAssetBundleのLoad/Unload処理、及びAssetのLoadをシンプルに取り扱うためのクラスです
  - １クラスにつき１つのAssetBundleの管理を行います（使い回し不可）
  - `MonoBehaiviour`を継承しており、このクラスが削除される際にUnloadが自動的に呼ばれるため、Unloadの独自管理をしたい場合は不向きです。
  - 他、使用方法は[AssetLoader.md](Docs/AssetLoader.md)を参照して下さい
- AssetBundleの参照カウントのデクリメントが行われていないバグを修正
- 通信系エラーコード追加
  - `DownloadErrorCode.NETWORK_UNKNOWN_REASON`
    - 通信成功したが情報が空など、意図しない問題が起きた
  - `DownloadErrorCode.NETWORK_UNREACHABLE`
    - ネットワークに繋がっていません
  - `DownloadErrorCode.NETWORK_FORBIDDEN`
    - Forbidden (HttpStatusCode:403)
  - `DownloadErrorCode.NETWORK_NOT_FOUND`
    - File not found (HttpStatusCode:404)
  - `DownloadErrorCode.NETWORK_INTERNAL_SERVER_ERROR`
    - Internal Server Error (HttpStatusCode:500)
  - `DownloadErrorCode.NETWORK_SERVICE_UNAVAILABLE`
    - Service Unavailable (HttpStatusCode:503)
  - `DownloadErrorCode.NETWORK_TIMEOUT`
    - Timeout `(HttpStatusCode:408(Request Timeout)/504(Gateway Timeout))
  - `DownloadErrorCode.NETWORK_CLIENT_ERROR`
    - Client Error (HttpStatusCode:4xx)
  - `DownloadErrorCode.NETWORK_SERVER_ERROR`
    - Server Error (HttpStatusCode:5xx)

### v0.1.1 - 2016/01/26

- 依存関係のあるAssetBundleのダウンロード中に失敗した場合の内部ロールバック機構を追加
- Unloadで、Refferenceが0になっても、管理情報から削除されないバグを修正
- 同時同一アセットバンドルロードリクエストでエラーが発生するバグを修正
- データベースのダウンロードでエラーが発生すると無限ループに入るバグを修正 
- 相互依存・循環依存などの複雑な依存関係のAssetBundleをロードした時に無限ループに入るバグを修正
- データベースの管理方法を最適化し、レコード取得の速度が向上

### v0.1.0 - 2016/01/15

- API追加：GetNamesByTag
  - タグを指定すると、そのタグが付いているアイテムの名前を全て取得する
  - 依存関係を含むかどうか指定できる
- エディタ専用API追加：GetAllLoadedAssetBundles
  - ロード済みの全てのAssetBundleを返す
- エラーの仕様変更
  - オクトから返される全てのエラーは、Code (string)とMessage (string)が必ず含まれるクラスを返します
  - エラーコードはenumからstringに変更しました
  - 例えば、DownloadErrorが返される場合、エラーコードとして含まれる可能性があるのは、DownloadErrorCodeに定義されるもののみです
  - 詳しくはAPIリファレンスを

### v0.0.4 - 2016/01/14

- 低レベルAPI追加：事前ダウンロード機能とキャッシュ個別削除機能
  - 事前ダウンロード：`OctoManager.AssetBundleLoader.PreDownload`
  - キャッシュ個別削除機能：`OctoManager.DeleteCache`
- 1つにしか依存していないAssetBundleを正常にロードできないバグを修正
- ローカルDBの暗号化としてAESのキーを与えても暗号化されないバグを修正
- コードにXMLドキュメント追加
- [APIリファレンス](/pages/hilo/octo-unity)用意

### v0.0.3 - 2016/01/06

- IAssetOperator.GetMainAsset()を廃止
- IAssetOperator.LoadAsset<T>()とLoadAssetAsync<T>()を追加
  - それぞれLoadAsset<T>(IAssetOperator.Name)とLoadAssetAsync<T>(IAssetOperator.Name)を呼び出します
- IAssetBundleLoaderの廃止
  - あわせてOctoManager.AssetBundleLoaderも削除
  - シェーダーのウォームアップなどは、LoadAssetBundleを使ってIAssetOperatorを取得して行うようにお願いします

### v0.0.2 - 2016/01/05

- メニューのAssets/CreateからOctoSettingsを作る際、作成先を指定しなかったときの作成先をAssets/Resourcesに変更
- オクトのProto.DBを暗号化していないのに、protoc --decode_rawでdecodeできない問題を対応しました。
- 【バグ対応】2回目以降のDB更新で、DBが初期化されてしまう問題を対応しました
- OctoSettingsのmaxParallelLoadが実際には使われていないバグを修正

### v0.0.1 - 2016/01/04

ファーストリリース
