## index
* [Cachingについて](#cachingについて)
* [キャッシングタイプの選択方法](#キャッシングタイプの選択方法)
* [独自キャッシングを使用した素材のロード方法](#独自キャッシングを使用した素材のロード方法)
* [Octo独自CachingのIFについて](#octo独自cachingのifについて)
* [キャッシュのフォルダ構成について](#キャッシュのフォルダ構成について)
* [キャッシュの保存先について](#キャッシュの保存先について)

## Cachingについて
Octoでは、UnityのキャッシングとOcto独自キャッシングを選択できます
<br>
* Unityキャッシング<br>
Unityが提供するキャッシングを使用します。実装仕様については [Unityの公式ドキュメント](http://docs.unity3d.com/ScriptReference/Caching.html "Unityの公式ドキュメント")を参照ください<br>
チェックサムはCRCを使用します<br>
* Octo独自キャッシング<br>
Octoが用意したキャッシングを使用します。AssetBundle以外の素材についてもサポートします<br>
チェックサムはMD5を使用します<br>

## キャッシングタイプの選択方法
Octo.SettingsのCaching Typeを選択します。<br>
* Unity Default<br>
  Unityキャッシング<br>
* Octo Auto Delete<br>
  Octo独自キャッシング（自動削除あり）<br>
* Octo Full Cache<br>
  Octo独自キャッシング（自動削除なし）<br>
<br>

## 独自キャッシングを使用した素材のロード方法

### AssetBundleの場合<br>
   AssetBundleの場合は、Unityキャッシングと同じように使用することができます<br>
```cs
OctoManager.LoadAssetBundle("SomeAssetName", OnLoad); 

   AssetLoaderを使用する場合も同じように使用することが可能です。
     AssetLoader _loader;
     _loader = gameObject.AddComponent<AssetLoader>();
     _loader.Setup ("SomeAssetName");
     _loader.LoadAsset<UnityEngine.GameObject> ("SomeAssetName", OnLoadLoader);
```

### AssetBundle以外の素材<br>
サポートしている形式は以下のとおりです<br>
* byte[]<br>
* string<br>
* Texture2D<br>
* AudioClip<br>

いずれの素材もUnity Defaultを使う場合は使用できません
<br>
実装例:<br>
```cs
例:PNGをロード
RawImage rawimg;

OctoManager.ResourceLoader.LoadFromCacheOrDownload<Texture2D>("SomePngName.png", OnLoadResource);
void OnLoadResource(Texture2D data, LoadError error)
{
   rawimg.texture = data;
}
```

### AssetBundleLoader/ResourceLoaderの事前ダウンロード(PreDownload)

```cs
例:アセットバンドルを事前ダウンロード
  OctoManager.AssetBundleLoader.PreDownload(SomeAssetName, OnLoad_pre);
  void OnLoad_pre(DownloadError error)
    {...
    
例:独自キャッシュでmov素材を事前ダウンロードして再生
  OctoManager.ResourceLoader.PreDownload (SomeAssetName, (res) =>
  {
     string videoPath = OctoManager.Caching.GetResourceStoragePath(SomeAssetName);
      Handheld.PlayFullScreenMovie (
          videoPath,
          Color.black,
          FullScreenMovieControlMode.CancelOnInput);
  });
```
### キャッシュの個別削除方法
キャッシュの個別削除はOctoManagerのDeleteAssetBundleCacheを使用します

```cs
OctoManager.DeleteAssetBundleCache("SomeAssetName");
```

### キャッシュの全削除方法
キャッシュの全削除はCachingのCleanCacheを使用します。
UnityEditorであれば、メニューより削除することも可能です。

```cs
OctoManager.Caching.CleanCache();
  ※UnityEditor限定でメニューからクリアすることも可能
　  Octo > Clean Unity Cache
　  Octo > Clean Octo Cache
```


## Octo独自CachingのIFについて

|                           |                                                                      | 初期設定値 | FullCacheで無効 |
|---------------------------|----------------------------------------------------------------------|------------|-----------------|
| IsReady                   | キャッシュ準備可否 ローカルファイル情報の取得が正常に 完了したらtrue |      -     |                 |
| ExpirationDelay           | キャッシュの有効秒数（設定値0であれば、有効期限無し）                |      0     |        ○        |
| MaximumAvailableDiskSpace | キャッシュ保存最大容量(byte)                                         |     1GB   |        ○        |
| SpaceFree                 | 現在利用可能な容量(byte)                                             |     -      |                 |
| SpaceOccupied             | 現在使用中の容量(byte)                                               |      -     |        ○        |
| IsLatestAssetBundleCached | 指定されたABのキャッシュが最新か AssetBundle用                       |      -     |                 |
| IsLatestResourceCached    | 指定された素材のキャッシュが最新か 独自素材用                        |      -     |                 |
| CleanCache                | 削除できるキャッシュを削除する ロード中の素材は削除しない            |      -     |                 |
| GetResourceStoragePath    | 独自素材のローカルパスを取得する (パス指定での動画等の再生用)        |      -     |                 |
#### 設定例
```cs
キャッシュ有効期限を3ヶ月
OctoManager.Caching.ExpirationDelay = 7776000;

最大ディスク容量を4GB
OctoManager.Caching.MaximumAvailableDiskSpace = 1024*1024*1024*4;

```

## キャッシュのフォルダ構成について
![cache_image](images/cache_folder.png)


[Caches] - [Octo] - [v1] - [※appid] - [0]〜[F] - [※assetbundleName]　or [※ResourceName] - [※md5string] 

#### 補足
- ハッシュ化したアセットバンドル名/素材名の最終文字(0〜F)によって、0〜Fのディレクトリに振り分けられる
- ※appid = OctoSettingのappidの数字が入る
- assetbundleName = A + アセットバンドル名(ハッシュ化した素材名をHex化したもの)
- ResourceName = R + アセットバンドル以外の素材名(ハッシュ化した素材名をHex化したもの)
- md5string = キャッシュファイル名 + (拡張子は、アセットバンドル以外で、ファイル名に".wav"".mp3":".mp4":".mov":".mpv":".3gp"の拡張子の時に付与)
- 素材名フォルダ配下のキャッシュファイル(md5string)は最新の1つしか存在せず、古いファイルは保持しない

## キャッシュの保存先について
##### PC(Mac,Windows)
Application.persistentDataPath + "/Caches/Octo/..."
```
 mac:/Users/USER_NAME/Library/Application Support/DefaultCompany/octo-unity-tester/Library/Caches/Octo/..."
 win:/Users/USER_NAME/AppData/LocalLow/DefaultCompany/octo-unity-tester/Library/Caches/Octo/..."
```
```
※オプション(プロジェクトルートに保存)
OCTO_EDITOR_CACHE_APPROOTがscripting symbolsに設定すると
プロジェクトルート + "/app_root/octo/caches/..."に保存先を設定することも可能
```

##### iOS
Application.temporaryCachePath + "/Caches/Octo/..."
```
/var/mobile/Applications/<アプリのID>/Library/Caches/Octo/..."
```

##### Android
Application.persistentDataPath + "/Caches/Octo/..."
```
/data/data/<アプリのID>/files/Caches/Octo/..."
```
