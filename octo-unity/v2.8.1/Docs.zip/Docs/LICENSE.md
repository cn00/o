License of OCTO Unity SDK is [here](Assets/Octo/License.txt)
