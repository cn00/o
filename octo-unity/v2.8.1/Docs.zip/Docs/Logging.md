# Logging機能

## Logger

octo-unityでは、Loggerを使用者側で自由に設定できるように、 `Octo.OctoManger.Logger`プロパティを用意しています。
[UnityEngine.ILogger](http://docs.unity3d.com/ScriptReference/ILogger.html) のインターフェースになっているので、
これを実装したロガーであれば自由に変更可能です。
これを用いることで、例えば本番用アプリだけログをファイルに保存するなど、細かい調整が可能となります。

### デフォルトのLogger

`Octo.OctoManager.Logger` にデフォルトで入っているロガーは `UnityEngine.Debug.logger` になります。
そのためデフォルト状態であれば、 `UnityEngine.Debug.Log` への出力と同等です。

### カスタムロガー

以下よくあるカスタムロガーのサンプル集となります。

#### ログ出力・ログレベルを制御できるロガー

```cs
using UnityEngine;
using Octo;

var logger = new Logger(Debug.logger.logHandler);
OctoManager.Logger = logger;

// ログを出力しない
logger.logEnabled = false;
// ログを出力する
logger.logEnabled = true;

// 出力するログレベルを例外のみ
logger.filterLogType = LogType.Exception;
// 出力するログレベルをエラー以上に
logger.filterLogType = LogType.Error;
// 出力するログレベルをアサート以上に
logger.filterLogType = LogType.Assert;
// 出力するログレベルを警告以上に
logger.filterLogType = LogType.Warning;
// 出力するログレベルを全てに
logger.filterLogType = LogType.Log;
```

#### 出力されるログレベルを書き換えるロガー

```cs
using UnityEngine;
using Octo;

public class MyLogHandler : ILogHandler
{
    private ILogHandler inner;

    public MyLogHandler(ILogHandler inner)
    {
        this.inner = inner;
    }

    public void LogFormat(LogType logType, UnityEngine.Object context, string format, params object[] args)
    {
        if (logType == LogType.Error) logType = LogType.Warning; // エラーログは警告ログに
        inner.LogFormat(logType, context, format, args);
    }

    public void LogException(Exception exception, UnityEngine.Object context)
    {
        inner.LogException(exception, context);
    }
}

OctoManager.Logger = new Logger(new MyLogHandler(Debug.logger.logHandler));
```

## より細かいLogging

デフォルトで無効化されていますが、octo-unityではトレースログやパフォーマンスログも出力することが可能です。
これらについては、ロギングがパフォーマンスに影響しないようにプリプロセッサで制御されており、
特定のシンボルを定義することで、有効化することができます。

実際にトレースログやパフォーマンスログを有効化する場合、
エディタ上の `Octo/Log` の中にあるメニューから有効／無効を切り替えることができます。

また他の方法でシンボルを制御している用いている場合、以下のシンボルを必要に応じて追加して下さい。

- トレースログ： `OCTO_LOG_TRACE`
- パフォーマンスログ： `OCTO_LOG_PERFORMANCE`
