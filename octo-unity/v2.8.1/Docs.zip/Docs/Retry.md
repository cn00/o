# APIのリトライについて

octo-unityでは、通信毎の細かいリトライハンドリングが可能です。
エラーコードに応じてユーザーにメッセージを表示させつつ、ユーザーが選択するまで待機し、
その後選択結果に応じて通信をリトライさせたり、終了させたりできます。

## 通信リトライ方法

`Octo.OctoManager.DownloadErrorInteceptor` に、アプリ任意のハンドラーを入れます。

delegateの型は `public delegate IEnumerator DownloadErrorHandler(DownloadError error, Action requestRetry);` です。
第1引数にエラー情報、第2引数にリトライしたいときに実行するActionが渡されます。
またインターセプター自体はコルーチンとして実行されるので、アプリ側で任意の時間止めることが可能です。

### サンプル

```cs
        private IEnumerator DownloadErrorHandler(Octo.DownloadError error, Action requestRetry)
        {
            switch (error.Code) {
            case DownloadErroCode.NetworkCommunication:
            case DownloadErroCode.NetworkTimeout:
            case DownloadErroCode.NetworkUnreachable:
            case DownloadErroCode.NetworkMd5Checksum:
            case DownloadErroCode.NetworkServiceUnavailable:
            case DownloadErroCode.NetworkServerError:
            case DownloadErroCode.NetworkUnknownReason:
                {
                    var dialog = new RetryDialog();
                    yield return dialog.Open();
                    if (dialog.retry) {
                        requestRetry(); // リトライする
                    }
                }
                break;
            default:
                {
                    var dialog = new JumpTitleDialog();
                    yield return dialog.Open();
                    GoTitle();
                }
                break;
            }
        }
```

## リトライすべきエラーコード

- NetworkCommunication
- NetworkTimeout
- NetworkUnreachable
- NetworkMd5Checksum
- NetworkServiceUnavailable
- NetworkServerError
- NetworkUnknownReason

500番台もサーバー側のネットワーク不調の可能性があるため、リトライすると改善する可能性があります。

## リトライすべきでないエラーコード

リトライしても改善されない可能性があるため、タイトルに戻すなどをし、
CSでエラーコードが判別できるようにしてください。

- NetworkAuthentication
- NetworkClientError
- NetworkForbidden 
- NetworkInternalServerError
- NetworkNotFound

