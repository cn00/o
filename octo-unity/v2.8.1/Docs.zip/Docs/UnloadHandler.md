# UnloadHandler

OCTO Unity SDK v2.6以降ではアンロード処理の制御をカスタム可能です。
アンロードの戦略をカスタムで書くことによって、ゲームの状況に応じてアンロードしないように制御可能になります。
例えばクエストの再出撃時にAssetBundleをアンロードしないで維持するといったことが可能になります。

デフォルトでは以下の戦略が用意されています。

- SimpleUnloadHandler: 毎フレームの最後にアンロード可能なAssetBundleを一括でアンロードする（OCTO v2.6以降のデフォルト）
- DelayedFrameUnloadHandler: アンロード可能なAssetBundleができたxフレーム後に一括でアンロードする（xは指定可能）
- DelayedSecondsUnloadHandler: アンロード可能なAssetBundleができたx秒後に一括でアンロードする（xは指定可能）
- LegacyUnloadHandler: OCTO v2.6未満の戦略を再現したハンドラー（非推奨）

# UnloadHandlerのカスタム方法

Octo.IUnloadHandlerのインターフェイスを実装したクラスを用意して、初期化時のOctoFullSettings.UnloadHandlerに設定するか、
初期化後でもOctoManager.AssetBundleUnloadHandlerに設定することで差し替えられます。

## IUnloadHandlerの実装方法

実装すべきメソッドは2つだけです。

- void Init(IAssetBundleManager assetBundleManager)
- IEnumerator FrameLoop()

### Init

InitはIUnloadHanlderをOctoに登録した際に、Octo側から呼ばれます。
IAssetBundleManagerが渡されるので、それをフィールドにキャッシュして下さい。
この処理はUnloadHandlerBaseを継承することで省略できます。

### FrameLoop
コルーチンとしてOcto側が設定時に起動します。
この中で無限ループでアンロードの制御処理を記述して下さい。
アンロード可能なAssetBundleのリストは、Initで受け取ったIAssetBundleManager.GetUnloadableAssetBundlesで取得ができます。
そのリストに対して、IAssetBundleManager.UnloadAssetBundleにAssetBundle名とAssetBundleに紐づくAssetも一緒にアンロードするかどうかのフラグを渡すことでアンロードできます。

例えばSimpleUnloadHandlerのFrameLoopは以下のような実装になっています。
```cs
        public override IEnumerator FrameLoop()
        {
            while (true)
            {
                yield return _waitForEndOfFrame;

                foreach (var assetBundleName in _assetBundleManager.GetUnloadableAssetBundles())
                {
                    _assetBundleManager.UnloadAssetBundle(assetBundleName, _isUnloadAll);
                }
            }
        }
```

