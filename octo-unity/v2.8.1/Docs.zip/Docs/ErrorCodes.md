# Error & Error Codes

## エラーの種類

オクトから返却されるエラーの種類は以下の通りです。

- DownloadError
- LoadError
- AssetLoaderError

これらのエラーは互いに独立していなく、LoadErrorはDownloadErrorを包含しています。
APIとしてダウンロードしかしない場合はDownloadErrorを、
何らかのロードをする場合はLoadErrorを返すようになっています。

## エラーの持つ情報

各エラーには以下の2種類のstringを取得するプロパティがあります。

- Code
- Message

Codeは後述するエラーコードの中の1つになり、
Messageはエラーが起きた詳細な原因になります。
エラーを受け取ったら、必要に応じてCodeで処理を分岐させ、Messageをログに残すようにすることを推奨します。

## エラーコードの種類

オクトから返却されるエラーコードは、大別すると以下の4種類になります。

- DatabaseErrorCode
- DownloadErrorCode: DownloadErrorで含まれる可能性のあるエラーコード
- LoadErrorCode: LoadErrorで含まれる可能性のあるエラーコード
- AssetLoaderErrorCode: AssetLoaderErrorで含まれる可能性のあるエラーコード

これらは上から順番に継承されているので、DatabaseErrorCodeは他の全てのエラーコードに含まれています。
エラーと含まれる可能性のあるエラーコードの関係を表にすると、以下のようになります。

|                  | DatabaseErrorCode | DownloadErrorCode | LoadErrorCode | AssetLoaderErrorCode |
|------------------|:-----------------:|:-----------------:|:-------------:|:--------------------:|
| DownloadError    |        YES        |        YES        |      NO       |         NO           |
| LoadError        |        YES        |        YES        |      YES      |         NO           |
| AssetLoaderError |        YES        |        YES        |      YES      |         YES          |

## エラーコードの詳細

### DatabaseErrorCode

DatabaseErrorCodeで定義されているエラーコードは以下のようになります。

#### DatabaseNameNotFound

| 項目 | 説明 |
|------|------|
| 定義 | octo.database.name_not_found |
| 原因 | ユーザーが指定したAssetBundle名やリソース名が、現在のローカルDBの中に見つかりませんでした。 |
| 対処 | ローカルDBが古い可能性があります。DBの更新をすると解決する可能性があります。 |

----------------------------------------

### DownloadErrorCode

DownloadErrorCodeで定義されているエラーコードは以下のようになります。

#### NetworkUnknownReason

| 項目 | 説明 |
|------|------|
| 定義 | octo.network.unknown_reason |
| 原因 | 通信に起因して、予期せぬ事態が起こりました。 |
| 対処 | 一時的な通信の障害の可能性があります。時間をあけて、再度処理を実行して下さい。 |

#### NetworkUnreachable

| 項目 | 説明 |
|------|------|
| 定義 | octo.network.unreachable |
| 原因 | クライアントがネットワークに接続されていないことを検知しました。 |
| 対処 | ユーザーにネットワークに接続するように促し、再度処理を実行して下さい。|

#### NetworkCommunication

| 項目 | 説明 |
|------|------|
| 定義 | octo.network.communication |
| 原因 | WWW リクエスト返却時、特定のエラーコードないエラーが返ってきた時 |
| 対処 | 一時的な通信の障害の可能性があります。時間をあけて、再度処理を実行して下さい。 |

#### NetworkAuthentication

| 項目 | 説明 |
|------|------|
| 定義 | octo.network.authentication |
| 原因 | HttpStatusCode：401 が返されました<br>→認証に失敗した（OctoSettingsのclientSecretKeyが異なる）時に発生します |
| 対処 | リクエストされた情報が不正、もしくはアプリがアップデートされていない可能性があります。<br>アプリのアップデートを促して下さい。 |

#### NetworkForbidden

| 項目 | 説明 |
|------|------|
| 定義 | octo.network.forbidden |
| 原因 | HttpStatusCode：403 が返されました |
| 対処 | リクエストされた情報が不正、もしくはアプリがアップデートされていない可能性があります。<br>アプリのアップデートを促して下さい。 |

#### NetworkNotFound

| 項目 | 説明 |
|------|------|
| 定義 | octo.network.not_found |
| 原因 | HttpStatusCode：404 が返されました |
| 対処 | リクエストされた情報が不正、もしくはアップデートされていない可能性があります。<br>アプリやデータベースのアップデートを促して下さい。 |

#### NetworkInternalServerError

| 項目 | 説明 |
|------|------|
| 定義 | octo.network.internal_server_error |
| 原因 | HttpStatusCode：500 が返されました |
| 対処 |サーバー内部で問題が発生しました。<br>リトライしても回復しない場合があるので、ユーザーにリトライとお問い合わせができるようにして下さい。 |

#### NetworkServiceUnavailable

| 項目 | 説明 |
|------|------|
| 定義 | octo.network.service_unavailable |
| 原因 | HttpStatusCode：503 が返されました |
| 対処 | 一時的なサーバの障害の可能性があります。<br>ユーザーにリトライを促して下さい。 |

#### NetworkTimeout

| 項目 | 説明 |
|------|------|
| 定義 | octo.network.timeout |
| 原因 | HttpStatusCode：408 or 504 が返された、<br>またはダウンロード処理がタイムアウトしました |
| 対処 | 通信状況が悪い可能性があります。<br>ユーザーに通信環境を改善するように促し、再度処理を実行して下さい。 |

#### NetworkClientError

| 項目 | 説明 |
|------|------|
| 定義 | octo.network.client_error |
| 原因 | HttpStatusCode：4xx（クライアントエラー）が返されました |
| 対処 | リクエストされた情報が不正、もしくはアップデートされていない可能性があります。<br>アプリやデータベースのアップデートを促して下さい。 |

#### NetworkServerError

| 項目 | 説明 |
|------|------|
| 定義 | octo.network.server_error |
| 原因 | HttpStatusCode：5xx（サーバーエラー）が返されました |
| 対処 | 一時的なサーバの障害の可能性があります。ユーザーにリトライを促して下さい。 |

#### IOUsingOldCache


| 項目 | 説明 |
|------|------|
| 定義 | octo.io.using_old_cache |
| 原因 | 既にロードされているもの更新版をダウンロードしようとした |
| 対処 | ロードされているものの更新版をダウンロードすることはできません。アンロードしてからダウンロードするか、古いのをそのままロードして使用して下さい。 |

#### IOUnknownReason

| 項目 | 説明 |
|------|------|
| 定義 | octo.io.unknown_reason |
| 原因 | I/Oに起因した、想定外の事態が発生しました |
| 対処 | 一時的な障害の可能性があります。再度処理を実行すると改善される可能性があります。 |

#### IOStorageFull

| 項目 | 説明 |
|------|------|
| 定義 | octo.io.storage_full |
| 原因 | 書き込み先のディスク容量が不足していることを検知しました。 |
| 対処 | このエラーを受け取った場合、ユーザーにディスクの空き容量を増やすように促して下さい。|

#### IOPermission

| 項目 | 説明 |
|------|------|
| 定義 | octo.io.permission |
| 原因 | R/Wしようとしたファイルに対して、アクセス権限の問題が見つかりました。 |
| 対処 | 主にエディタ上で出現するエラーです。メッセージに表記されているパスをR/Wできるように設定を見直して下さい。 |

-------------------------------------

### LoadErrorCode

LoadErrorCodeで定義されているエラーコードは以下のようになります。

#### LoadUnknownReason

| 項目 | 説明 |
|------|------|
| 定義 | octo.load.unknown_reason |
| 原因 | ロード中に通常起き得ない、予期せぬ事態が起こりました。 |
| 対処 | 一時的な障害の可能性があります。時間をあけて、再度処理を実行して下さい。 |

#### LoadCancel

| 項目 | 説明 |
|------|------|
| 定義 | octo.load.cancel |
| 原因 | ロード処理が外からキャンセルされました。 |
| 対処 | ロード中だった場合は処理が続行されますが、後で自動的にアンロードされます。 |

-------------------------------------

### AssetLoaderErrorCode

AssetLoaderErrorCodeで定義されているエラーコードは以下のようになります。

#### AssetLoaderTypeDiffered

| 項目 | 説明 |
|------|------|
| 定義 | octo.asset_loader.type_differed |
| 原因 | AssetをLoadする際に違う型を指定してしまった |
| 対処 | （開発時）正しい型で指定してLoadして下さい。<br>（本番時）ローカルDBが古い可能性があります。DBの更新をすると解決する可能性があります。 |

#### AssetLoaderIncorrectName

| 項目 | 説明 |
|------|------|
| 定義 | octo.asset_loader.incorrect_name |
| 原因 | Load命令を出したAsset名が不正、または存在しないAsset名だった |
| 対処 | （開発時）正しい名前に修正して下さい。<br>（本番時）ローカルDBが古い可能性があります。DBの更新をすると解決する可能性があります。 |

#### AssetLoaderTypeDifferedOrIncorrectName

| 項目 | 説明 |
|------|------|
| 定義 | octo.asset_loader.type_differed_or_incorrect_name |
| 原因 | AssetLoaderIncorrectName もしくは AssetLoaderIncorrectName と同様 |
| 対処 | AssetLoaderIncorrectName もしくは AssetLoaderIncorrectName と同様 |

#### AssetLoaderUnknownReason

| 項目 | 説明 |
|------|------|
| 定義 | octo.asset_loader.unknown_reson |
| 原因 | エラーメッセージを確認してください |
| 対処 | エラーメッセージを頼りに解決してください |
