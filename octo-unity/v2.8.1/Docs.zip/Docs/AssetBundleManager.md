## AssetBundleManager とは？
OctoManagerから、以下のような処理を受けて受けて対応を行います。
- AssetBundleのロード
- AssetBundleのアンロード
- AssetBundleのロードキャンセル


###ロードフロー
* 1.OctoManagerのLoadAssetBundleを実行
* 2.loadRequestIDを発行
* 3.参照カウント＋して、ロードリリクエストをキューイング
* 4.リクエスト情報がLoadFromCacheOrDownloadの実行
* 5.ロード完了！（エラー発生時はロールバック処理）
  

###アンロードフロー
* 1.OctoManagerのUnloadAssetBundleを実行
* 2.アンロードリクエストをキューイング
* 3.Frame実行されるUpdateで、.アンロードリクエストキューをチェック、ロード完了でアンロード実行
    (1フレーム当たりに実行されるアンロードは１つのみです)

###キャンセルフロー
* 1.OctoManagerのCancelLoadingAssetBundleを実行
* 2.呼び出し元にすぐにコールバック
* 3.ロールバックのリクエスト情報を生成して、ロードキャンセル
 

###ロード・アンロード・キャンセルにおける依存関係の扱いについて

- ロード時は、全ての依存関係のアセットバンドルをロードリクエストとしてキューイングし、参照カウントを１つ増やす
- アンロード時も同様に全ての依存関係のアセットバンドルをリクエストにキューイングし、参照カウントを１つ減らす
- キャンセル時やロードエラー時は、全ての依存関係にあるロードを取り消して、参照カウントを戻す

![abm_explanation](images/abm_explanation.png)
