# AssetOperator

## index
* [AssetOperatorとは](#assetoperatorとは)
* [AssetDatabaseの使用方法](#assetdatabaseの使用方法)
 - [AssetDatabaseを有効にする際の注意点](#assetdatabaseを有効にする際の注意点)
* [関数一覧](#関数一覧)
 - [Name](#name)
 - [ReferenceCount](#referencecount)
 - [LoadAsset](#loadasset)
 - [LoadAssetAsync](#loadassetasync)
 - [LoadAllAssets](#loadallassets)
 - [LoadAllAssetsAsync](#loadallassetsasync)
 - [LoadAssetWithSubAssets](#loadassetwithsubassets)
 - [LoadAssetWithSubAssetsAsync](#loadassetwithsubassetsasync)
 - [Unload](#unload)
 - [Contains](#contains)
 - [GetAllAssetNames](#getallassetnames)
* [IAssetOperatorの派生クラス](#iassetoperatorの派生クラス)
 - [AssetBundleOperator](#assetbundleoperator)
 - [AssetDatabaseOperator](#assetdatabaseoperator)



## AssetOperatorとは

オクト側で管理しているAssetBundleを操作するI/Fです。<br>
`OctoManager.LoadAssetBundle`が成功した際に、コールバックにて受け取れます。<br>
基本的に`UnityEngine.AssetBundle`と同等の関数を用意しています（一部例外除く。詳細はAPIリファレンス、または[関数一覧](#関数一覧) / [IAssetOperatorの派生クラス](#iassetoperatorの派生クラス)を参照下さい）。

## AssetDatabaseの使用方法

オクトへAssetBundleのLoadリクエストをした際、<br>
通常はオクトDBで管理されているAssetBundleをLoadし、オクトが管理しますが、<br>
サーバに上げる前のテスト用として、同I/Fを使ってAssetDatabaseを使ってのLoad操作も出来ます。<br>
<br>
AssetDatabaseは`OctoManager.EnableAssetDatabase();`を呼ぶことで利用出来ます（**only UNITY_EDITOR**）。<br>
必要に応じて、AssetBundleのロード前に予め呼んで下さい。<br>
有効になっていれば、プロジェクトにアセットが存在する場合、自動的にAssetDatabaseを使います。<br>
存在しない場合は通常通り、オクトで管理するAssetBundleを使用します。<br>

ex.

```cs
using Octo;

#if UNITY_EDITOR
if(使用する？)
{
    OctoManager.EnableAssetDatabase();
    // 以降のLoad/UnloadではAssetDatabaseが存在するか確認するように
}
#endif
```

### AssetDatabaseを有効にする際の注意点

AssetDatabaseが有効になっていると、<br>
`OctoManager.LoadAssetBundle / OctoManager.UnloadAssetBundle`の内部にて、<br>
まずAssetDatabaseが存在するか確認し、存在すればオクトDBは無視してAssetDatabaseを参照するため、<br>
例えば、<br>
<br>
LoadAssetBundle<br>
↓<br>
EnableAssetDatabase<br>
↓<br>
UnloadAssetBundle<br>
<br>
の順番に呼ぶと、AssetBundleがUnloadされない可能性があります。<br>
<br>
ですので、`OctoManager.EnableAssetDatabase`を呼ぶ際は、初期化時（`OctoManager.Setup`の前後など）がベターです。<br>
また、一度有効にした後は、無効には出来ません。<br>



## 関数一覧

### Name
AssetBundle名の取得（プロパティ）<br>
`string Name { get; }`

- `OctoManager.LoadAssetBundle`でリクエストしたAssetBundle名が受け取れます。

### ReferenceCount
オクト側で管理しているAssetBundle参照している数の取得（プロパティ）<br>
`int ReferenceCount { get; }`

- ReferenceCount が0になれば、AssetBundleがアンロード([AssetBundle.Unload](http://docs.unity3d.com/current/ScriptReference/AssetBundle.Unload.html))されます。<br>
ただし、[AssetDatabase](http://docs.unity3d.com/current/Manual/AssetDatabase.html)の場合、オクト側で管理している訳ではないので常に`ReferenceCount==0`です（[→詳細](#assetdatabaseoperator)）<br>
- 通常使う必要は無いと思いますが、テスト時など、何かの参考にどうぞ。

### LoadAsset
同期Assetロード<br>
**引数なし**<br>
`T LoadAsset<T>() where T : UnityEngine.Object;`<br>
　※ AssetBundle内に内包されているAssetが一つの場合に使用出来ます。<br>
　　複数Assetがある場合は`null`が返ります。<br>
**引数あり**<br>
`T LoadAsset<T>(string assetName) where T : UnityEngine.Object;`<br>

ex. 

```cs
//使用例（Type=GameObjectの場合）
using Octo;

// AssetBundle Load.
OctoManager.LoadAssetBundle("AssetBundle名", OnComplete);

void OnComplete(IAssetOperator opr, LoadError err)
{
    //-----------------------------------//
    // (Error Check.)
    //-----------------------------------//

    // DB & Load success.
    var go = opr.LoadAsset<GameObject>("Asset名");
    Instantiate(go);
}
```

### LoadAssetAsync
非同期Assetロード<br>
**引数なし**<br>
`LoadRequest<T> LoadAssetAsync<T>() where T : UnityEngine.Object;`<br>
　※ AssetBundle内に内包されているAssetが一つの場合に使用出来ます。<br>
　　複数Assetがある場合は`null`が返ります。<br>
**引数あり**<br>
`LoadRequest<T> LoadAssetAsync<T>(string assetName) where T : UnityEngine.Object;`<br>

ex.

```cs
//使用例（Type=GameObjectの場合）
using Octo;

void OnComplete(IAssetOperator opr, LoadError err)
{
    //-----------------------------------//
    // (Error Check.)
    //-----------------------------------//

    // DB & Load success.
    StartCoroutine(InstantiateAssetAsync(opr, "Asset名"));
}

IEnumerator InstantiateAssetAsync(IAssetOperator opr, string assetName)
{
    LoadRequest<GameObject> loadreq = opr.LoadAssetAsync<GameObject>(assetName);
    yield return StartCoroutine(loadreq);
    var go = loadreq.asset;
    GameObject.Instantiate(go);
}
```

### LoadAllAssets
AssetBundleが内包している、指定した型のAssetを全てロード<br>
`T[] LoadAllAssets<T>() where T : UnityEngine.Object;`

### LoadAllAssetsAsync
AssetBundleが内包している、指定した型のAssetを全て非同期ロード<br>
`LoadRequest<T> LoadAllAssetsAsync<T>() where T : UnityEngine.Object;`

ex.

```cs
//使用例（Type=GameObjectの場合）
using Octo;

void OnComplete(IAssetOperator opr, LoadError err)
{
    //-----------------------------------//
    // (Error Check.)
    //-----------------------------------//

    // DB & Load success.
    StartCoroutine(InstantiateAssetsAllAsync(opr));
}

IEnumerator InstantiateAssetsAllAsync(IAssetOperator opr)
{
    LoadRequest<GameObject> loadreq = opr.LoadAllAssetsAsync<GameObject>();
    yield return StartCoroutine(loadreq);
    
    for (int i = 0; i < loadreq.allAssets.Length; i++)
    {
        var go = loadreq.allAssets[i];
        GameObject.Instantiate(go);
    }
} 
```

### LoadAssetWithSubAssets
SubAssetsのロード（[AssetBundle.LoadAssetWithSubAssets](http://docs.unity3d.com/ScriptReference/AssetBundle.LoadAssetWithSubAssets.html)と同等の処理）<br>
`T[] LoadAssetWithSubAssets<T>(string assetName) where T : UnityEngine.Object;`

### LoadAssetWithSubAssetsAsync
SubAssetsの非同期ロード<br>
`LoadRequest<T> LoadAssetWithSubAssetsAsync<T>(string assetName) where T : UnityEngine.Object;`

ex.

```cs
//使用例（Type=Spriteの場合）
using Octo;

void OnComplete(IAssetOperator opr, LoadError err)
{
    //-----------------------------------//
    // (Error Check.)
    //-----------------------------------//

    // DB & Load success.
    StartCoroutine(InstantiateSubAssetsAsync(opr));
}

IEnumerator InstantiateSubAssetsAsync(IAssetOperator opr)
{
    LoadRequest<UnityEngine.Sprite> loadreq = opr.LoadAssetWithSubAssetsAsync<UnityEngine.Sprite>("Asset名");
    yield return StartCoroutine(loadreq);

    for (int i = 0; i < loadreq.allAssets.Length; i++)
    {
        var go = loadreq.allAssets[i];
        // 各処理
    }
} 
```

### Unload
Unload処理を行います。<br>
`void Unload();`

- 内部にて、`OctoManager.UnloadAssetBundle`を呼びます。<br>
以降のLoad系メソッドは使用できなくなり、呼んでもnullが返るのでご注意下さい。<br>
ただし、[AssetDatabase](http://docs.unity3d.com/current/Manual/AssetDatabase.html)の場合、オクト側で管理している訳ではないので`Unload`を呼んでも何も処理しません（[→詳細](#assetdatabaseoperator)）

### Contains
特定のオブジェクトがアセットバンドルに含まれているか確認します（[AssetBundle.Contains](http://docs.unity3d.com/ScriptReference/AssetBundle.Contains.html)と同等の処理）<br>
`bool Contains(string assetName);`

### GetAllAssetNames
内包されている全てのAsset名を取得します（[AssetBundle.GetAllAssetNames](http://docs.unity3d.com/ScriptReference/AssetBundle.GetAllAssetNames.html)と同等の処理）<br>
`string[] GetAllAssetNames();`

## IAssetOperatorの派生クラス

`OctoManager.LoadAssetBundle`が呼ばれた際に、<br>
内部で判別し、生成しているIAssetOperatorの派生クラスの説明です。<br>
以下は見なくても実装出来ますが、内部実装の確認用にどうぞ。<br>
<br>
IAssetOperatorの派生クラスは下記の通りです。<br>

| クラス                                           | 説明                                        |
|-------------------------------------------------|--------------------------------------------|
| [AssetBundleOperator](#assetbundleoperator)     | 通常のオクトが管理しているAssetBundleの操作クラス |
| [AssetDatabaseOperator](#assetdatabaseoperator) | AssetDatabaseを使用した操作クラス（**only UNITY_EDITOR**）[→使い方](#assetdatabaseの使用方法) |


### AssetBundleOperator

Assetの操作時は、内部にて`UnityEngine.AssetBundle`の関数を呼んでいます。<br>
基本的な説明は[関数一覧](#関数一覧)を参照下さい（一部重複説明あり）。

| 関数（リンクは[関数一覧](#関数一覧)の各説明）                      | 内部実装（特筆するものがあれば） | Unload後の処理 | 
|-------------------------------------------------------------|----------------------------|---------------|
| [Name](#name)                                               |                            | 同じ           |
| [ReferenceCount](#referencecount)                           | オクト側で管理している参照カウント | 同じ |
| [LoadAsset](#loadasset)                                     | Call:[AssetBundle.LoadAsset](http://docs.unity3d.com/ScriptReference/AssetBundle.LoadAsset.html) | return null |
| [LoadAssetAsync](#loadassetasync)                           | Call:[AssetBundle.LoadAssetAsync](http://docs.unity3d.com/ScriptReference/AssetBundle.LoadAssetAsync.html) | return null |
| [LoadAllAssets](#loadallassets)                             | Call:[AssetBundle.LoadAllAssets](http://docs.unity3d.com/ScriptReference/AssetBundle.LoadAllAssets.html) | return null |
| [LoadAllAssetsAsync](#loadallassetsasync)                   | Call:[AssetBundle.LoadAllAssetsAsync](http://docs.unity3d.com/ScriptReference/AssetBundle.LoadAllAssetsAsync.html) | return null |
| [LoadAssetWithSubAssets](#loadassetwithsubassets)           | Call:[AssetBundle.LoadAssetWithSubAssets](http://docs.unity3d.com/ScriptReference/AssetBundle.LoadAssetWithSubAssets.html) | return null |
| [LoadAssetWithSubAssetsAsync](#loadassetwithsubassetsasync) | Call:[AssetBundle.LoadAssetWithSubAssetsAsync](http://docs.unity3d.com/ScriptReference/AssetBundle.LoadAssetWithSubAssetsAsync.html) | return null |
| [Unload](#unload)                                           | Call:`OctoManager.UnloadAssetBundle`（１度だけ） | 処理しない |
| [Contains](#contains)                                       | Call:[AssetBundle.Contains](http://docs.unity3d.com/ScriptReference/AssetBundle.Contains.html) | return false |
| [GetAllAssetNames](#getallassetnames)                       | Call:[AssetBundle.GetAllAssetNames](http://docs.unity3d.com/ScriptReference/AssetBundle.GetAllAssetNames.html)<br>（取得した情報は内部変数に格納するため、１度だけ呼ぶ） | return null |


### AssetDatabaseOperator

Assetの操作時は、内部にて`UnityEngine.AssetDatabase`の関数を呼んでいます。<br>
[AssetBundleOperator](#assetbundleoperator) が通常使用するクラスのため、それに合わせた情報が取得/処理出来るようにしています。<br>
そのため、内部にて一部トリッキーな処理を行っています。<br>
ちなみに、非同期ロードは**存在しません**（同じI/Fにするため、非同期関数には対応していますが、内部は同期処理です）。<br>

基本的な説明は[関数一覧](#関数一覧)を参照下さい（一部重複説明あり）。<br>

| 関数（リンクは[関数一覧](#関数一覧)の各説明）                      | 内部実装（特筆するものがあれば）                 ||-------------------------------------------------------------|--------------------------------------------|| [Name](#name)                                               |                                            || [ReferenceCount](#referencecount)                           | 常に0（オクト側で管理していないので）            || [LoadAsset](#loadasset)                                     | Call:[AssetDatabase.GetAssetPathsFromAssetBundleAndAssetName](http://docs.unity3d.com/ScriptReference/AssetDatabase.GetAssetPathsFromAssetBundleAndAssetName.html)<br>（[→詳細](#loadassetの内部処理)） || [LoadAssetAsync](#loadassetasync)                           | Call:[LoadAsset](#loadasset) || [LoadAllAssets](#loadallassets)                             | Call:[AssetDatabase.GetAssetPathsFromAssetBundle](http://docs.unity3d.com/ScriptReference/AssetDatabase.GetAssetPathsFromAssetBundle.html)<br>Call:[AssetDatabase.LoadAllAssetsAtPath](http://docs.unity3d.com/ScriptReference/AssetDatabase.LoadAllAssetsAtPath.html)<br>（[→詳細](#loadallassetsの内部処理)） || [LoadAllAssetsAsync](#loadallassetsasync)                   | Call:[LoadAllAssets](#loadallassets) || [LoadAssetWithSubAssets](#loadassetwithsubassets)           | Call:[AssetDatabase.GetAssetPathsFromAssetBundleAndAssetName](http://docs.unity3d.com/ScriptReference/AssetDatabase.GetAssetPathsFromAssetBundleAndAssetName.html)<br>Call:[AssetDatabase.LoadAssetAtPath](http://docs.unity3d.com/ScriptReference/AssetDatabase.LoadAssetAtPath.html)<br>Call:[AssetDatabase.LoadAllAssetRepresentationsAtPath](http://docs.unity3d.com/ScriptReference/AssetDatabase.LoadAllAssetRepresentationsAtPath.html)<br>（[→詳細](#loadassetwithsubassetsの内部処理)） || [LoadAssetWithSubAssetsAsync](#loadassetwithsubassetsasync) | Call:[LoadAssetWithSubAssets](#loadassetwithsubassets) || [Unload](#unload)                                           | 何もしない（オクト側で管理していないので） || [Contains](#contains)                                       | Call:[AssetDatabase.GetAssetPathsFromAssetBundleAndAssetName](http://docs.unity3d.com/ScriptReference/AssetDatabase.GetAssetPathsFromAssetBundleAndAssetName.html) || [GetAllAssetNames](#getallassetnames)                       | Call:[AssetDatabase.GetAssetPathsFromAssetBundle](http://docs.unity3d.com/ScriptReference/AssetDatabase.GetAssetPathsFromAssetBundle.html)<br>（[→詳細](#getallassetnamesの内部処理)） |<br>
----※以下は更に具体的な内部の話なので、興味のある方だけご覧下さい。
#### LoadAssetの内部処理AssetBundleと違う点は、型指定でピンポイントにAssetのロードが出来ないため、<br>
まずは[AssetDatabase.GetAssetPathsFromAssetBundleAndAssetName](http://docs.unity3d.com/ScriptReference/AssetDatabase.GetAssetPathsFromAssetBundleAndAssetName.html)を呼び出し、指定したAsset名の配列を取得します。<br>
<br>この際、**拡張子付きで指定をすると情報が取得できない**ため、呼び出し先からのAsset名から拡張子を外す必要があります（※AssetBundleの場合は、拡張子付きでもOK）<br>
<br>
[AssetDatabase.GetAssetPathsFromAssetBundleAndAssetName](http://docs.unity3d.com/ScriptReference/AssetDatabase.GetAssetPathsFromAssetBundleAndAssetName.html)で取得出来た名前が複数の場合、<br>
[LoadAsset](#loadasset)呼び出し時に指定したAsset名に拡張子をつけていれば、配列内を拡張子で検索をかけます。<br>
（拡張子が指定されていなければ、もしくは該当の拡張子が無ければ、配列の最初のパスを使用します）<br>
<br>
ロードするパスが確定したら[AssetDatabase.LoadAssetAtPath](http://docs.unity3d.com/ScriptReference/AssetDatabase.LoadAssetAtPath.html)を呼んでロードします。

ex.

```cs
AssetBundle hogehoge に
hoge.dat
hoge.mat
hoge.png
というAssetが存在した場合の、LoadAsset内部処理。

//-------------------------
// ① LoadAsset<T>("hoge.dat") とリクエストした場合

LoadAsset内部にて、
AssetDatabase.GetAssetPathsFromAssetBundleAndAssetName("hogehoge", "hoge") をCall
→ 配列取得（３要素）
→ 同じ拡張子（.dat）付きがあるかチェック
→ AssetDatabase.LoadAssetAtPath Call.（拡張子＝型と関連付いている筈なので保証あり）

//-------------------------
// ② LoadAsset<T>("hoge") とリクエストした場合

LoadAsset内部にて、
AssetDatabase.GetAssetPathsFromAssetBundleAndAssetName("hogehoge", "hoge") をCall
→ 配列取得（３要素）
→ １番目の配列を返却
→ AssetDatabase.LoadAssetAtPath Call.（型の保証なし）
```#### LoadAllAssetsの内部処理[AssetDatabase.GetAssetPathsFromAssetBundle](http://docs.unity3d.com/ScriptReference/AssetDatabase.GetAssetPathsFromAssetBundle.html)を呼んでAssetのパス一覧を取得してロードします。<br>
<br>
パス指定でロードする[AssetDatabase.LoadAllAssetsAtPath](http://docs.unity3d.com/ScriptReference/AssetDatabase.LoadAllAssetsAtPath.html)では、**型指定が出来ない**ため、<br>
ロード後に指定された型かをチェックして、指定した型であれば配列に入れて返します。<br>
#### LoadAssetWithSubAssetsの内部処理[LoadAssetの内部処理](#loadassetの内部処理)と同様、<br>
[AssetDatabase.GetAssetPathsFromAssetBundleAndAssetName](http://docs.unity3d.com/ScriptReference/AssetDatabase.GetAssetPathsFromAssetBundleAndAssetName.html)を拡張子抜きで実行します。<br>
<br>
`AssetBundleOperator`と同等の返り値にするため、<br>
取得出来たパスのAssetと、そのAssetに内包されたAssetの中で、指定した型であるAssetを配列で返します。<br>

- 取得出来たパスのAssetを直接Load：[AssetDatabase.LoadAssetAtPath](http://docs.unity3d.com/ScriptReference/AssetDatabase.LoadAssetAtPath.html)<br>
- 取得出来たパスのAsset内に含まれたAssetのLoad：<br>
（パス指定でロードする[AssetDatabase.LoadAllAssetRepresentationsAtPath](http://docs.unity3d.com/ScriptReference/AssetDatabase.LoadAllAssetRepresentationsAtPath.html)では、**型指定が出来ない**ため、ロード後に指定された型かをチェックして、指定した型であれば配列に入れて返します。）
#### GetAllAssetNamesの内部処理[LoadAssetの内部処理](#loadassetの内部処理)と同様、<br>
[AssetDatabase.GetAssetPathsFromAssetBundleAndAssetName](http://docs.unity3d.com/ScriptReference/AssetDatabase.GetAssetPathsFromAssetBundleAndAssetName.html)を拡張子抜きで実行します。<br>
<br>
取得したパス数が１以上であれば、trueを返します。