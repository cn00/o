## ユーザーキャッシュについて

Octo外のリソースの内部ストレージ管理を行う機能です。

### 使用方法

#### セットアップ

- OctoManager.SetupStorage(IUserCacheSetting setting)
  
  キャッシュ時の設定とキャッシュを行うクラスを生成します。
  キャッシュを追加、削除時は返り値の `IUserCaching` のAPIを使用して行います。
  このメソッドを呼び出す度に、ユーザーキャッシュ用のクラスが作られるため、同じ設定でキャッシュを行いたい場合はIUserCachingのインスタンスを使いまわしてください。
  
#### キャッシュの追加

- IUserCaching.PreDownload(string url, Action<IUserCacheResult> onCompleted, OnDownloadProgress onProgress)

  指定されたURLのリソースをダウンロードし、内部ストレージにキャッシュします。すでにキャッシュされている場合はダウンロードは行われず、即座に完了になります。
  キャッシュが完了したら `onCompleted` コールバックが呼ばれます。
  進捗は `onProgress` コールバックから取得できます。

- IUserCaching.Delete(string url)
  
  指定されたURLのリソースがキャッシュされていた場合、そのキャッシュを削除します。
  
#### パラメーター説明

- IUserCacheSetting

  `OctoManager.SetupStorage` の際に指定するクラスです。このクラスの設定により、保存場所等が変わります。

  - Name
    
    こちらで指定されたディレクトリ内にキャッシュが行われます。具体的には次のようなパスになります `Octo内部ストレージパス/Name/~~` 。
    
  - ExpirationDelay
    
    キャッシュの有効期間（秒）を設定できます。0の場合は無期限です。
    
  - MaximumAvailableDiskSpace
  
    キャッシュに割り当て可能なバイト数を設定できます。0の場合は無制限です。
    
- IUserCacheResult

  `IUserCaching.PreDownload` の 完了コールバックで渡されるクラスです。

  - Url
  
    指定されたURLです。
    
  - LocalPath
  
    キャッシュされているパスです。このパスを元にロード処理を行なってください。
    
  - Error
  
    エラー情報です。これがNullでなかった場合はキャッシュ途中でエラーが出ており、キャッシュが行われておりません。
    
 #### 例
 
```c#

var setting = new UserCacheSetting("test");
var caching = OctoManager.SetupStorage(setting);

var url = "https://placegoat.com/400";
caching.PreDownload(url, (result) =>
{
    if (result.Error != null)
    {
        // キャッシュ失敗
        Debug.LogError("Error : " + result.Error);
        return;
    }
    
    // キャッシュ成功
    Debug.LogFormat("Complete : {0}, {1}", result.LocalPath, result.Url);
    
    // キャッシュ読み込み
    using (var fs = new System.IO.FileStream(result.LocalPath, System.IO.FileMode.Open, System.IO.FileAccess.Read))
    {
        Debug.LogFormat("File Length : " + fs.Length);
    }
    
    // キャッシュ削除
    caching.Delete(url);
}, (url2, total, content) =>
{
    // 進捗
    Debug.LogFormat("Progress : {0}/{1}", total, content);
});

```
  
