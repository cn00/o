# octo-unity
Octo's sample project &amp; unity package

## index
* [システム要件](#システム要件)
* [構成](#構成)
* [事前準備-依存ライブラリの導入](#事前準備-依存ライブラリの導入)
* [事前準備-設定ファイルの作成](#事前準備-設定ファイルの作成)
* [初期化](#初期化)
* [オクトサーバからのDB更新](#オクトサーバからのdb更新)
* [AssetBundleの使用について](#assetbundleの使用)
  - [AssetBundleのLoad](#assetbundleのload)
  - [AssetBundleのUnload](#assetbundleのunload)
  - [LoadのCancel](#loadのcancel)<br>
* [AssetLoaderについて](#assetloaderについて)
* [Cachingについて](#cachingについて)
* [Errorについて](#errorについて)
* [APIリファレンス](#apiリファレンス)
* [仕様書](#仕様書)

## システム要件
* Unity5.3.3p1以上

5.3.3p1未満でも使用可能ですが、UnityのバグでiOSの場合に`Strip Engine Code`を無効にすると、
UnityWebRequestの初期化に失敗するバグがあります。
その場合、オプションを有効にするか、バージョンアップをお願いします。

## 構成
```
Octo
├── OctoManager - DBの管理などの基本処理を管理するメインクラス
├── OctoSettings, OctoFullSettings - OctoManager 初期設定情報
├── ICaching - OctoSettingsで選択したキャッシングを操作するI/F（OctoManager.Cachingから操作）
├── IAssetOperator - オクト側で管理しているAssetBundleを操作するI/F（OctoManager.LoadAssetBundleのコールバックで使用）
├── LoadRequest - IAssetOperator で使用するRequestクラス
├── AssetLoader - 単一のAssetBundleのLoad/Unload処理、及びAssetのLoadをシンプルに取り扱うためのクラス
└── Error - Error定義群
```

## 事前準備-依存ライブラリの導入

octo-unityは以下のライブラリに依存しています。
リンク先よりDLLをダウンロードし、プロジェクト内の任意の場所に置いて下さい。
既にプロジェクトに導入済みの場合は省略できます。

- [protobuf-net r668](https://code.google.com/archive/p/protobuf-net/downloads)

## 初期化
**※v2.3.0以降のバージョンではよりセキュアな方式で便利なOctoFullSettingsを用いた初期化が推奨されています。**

### OctoFullSettingsの各設定値の説明

- Url: オクトのURL (セキュリティ上、使用するプロジェクトへ個別に連絡)
- AppId: Octoの管理画面を参照
- ClientSecretKey: Octoの管理画面を参照
- AesKey: 各端末で保持されるDBのAESの暗号化鍵（指定無ければ暗号化されません）
- CachingType: 使用するCaching Type
- Version: App単位で管理されるversion。プラットフォームなどで変化（プロジェクト側で管理）
- UnloadAll: オクト内部で使われる、AssetBundle.Unload の引数
- MaxParallelDonwload: 同時ダウンロード数（0に設定すると内部デフォルト値が使われます）
- MaxParallelLoad:  同時ロード数（0に設定すると内部デフォルト値が使われます）
- MaximumAvailableDiskSpace: 各端末でキャッシュされる最大の容量（OctoFullCacheの場合は無視）
- ExpirationDelay: 使用されていないキャッシュが削除されるまでの秒数（OctoFullCacheの場合は無視）
- AllowDeleted: 論理削除のステータスのAssetBundleもロードできようにする（デバッグ用）
- EnableAssetDatabase: エディタ環境でAssetDatabaseを利用してAssetBundleをエミュレートするかどうか
- AssetLoaderPriority: AssetLoaderを使用する場合に、Resourcesを利用したロードのフォールバックモード

### サンプルコード

```cs
using Octo;

// Settingsの作成と設定 
var settings = new OctoFullSettings();
// URLなどの各設定値を入れる
// settings.Url = "";

// OCTOの機能を使用する前に必ず呼んで下さい
OctoManager.Setup(settings);
// 二度目以降のSetupは無視するようになっていますが、意図的に切り替えたい場合はresetフラグを立てて下さい
// OctoManager.Setup(settings, reset: true);
```

## オクトサーバからのDB更新

アプリ起動後、AssetBundle を使用する前にDBを更新して最新の情報を取得して下さい。<br>

```cs
using Octo;

OctoManager.StartDbUpdate(onComplete);

// Callback
void onComplete(DownloadError err)
{
    if (err != null)
    {
        // 通信エラー
        // err.codeでNetworkErrorCodeが取得できます
        return;
    }
    // success.
}
```

## AssetBundleの使用について

AssetBundleを使用する際には、<br>
① アプリ側でLoad/Unload/Cancelを管理してもらう方法と、<br>
② `MonoBehaiviour`を使ってシンプルに取り扱う方法（[→AssetLoaderについて](#assetloaderについて)）があります。<br>

以下は①についての使用方法です。

### AssetBundleのLoad

```cs
using Octo;

// AssetBundle Load.
OctoManager.LoadAssetBundle("AssetBundle名", OnComplete);

```

成功すると、コールバックで`IAssetOperator`が返ってきます。<br>
各自AssetをLoadしてご使用下さい（使い方は[APIリファレンス](#apiリファレンス)、または[AssetOperator.md](Docs/AssetOperator.md)を参照して下さい）。<br>
AssetBundleが不要になったタイミングで [Unload](#assetbundleのunload) を呼んで下さい。<br>
（※失敗すると`LoadError`が返ってきます。失敗した場合は Unload は**不要**です）<br>

```cs
// Callback
void OnComplete(IAssetOperator opr, LoadError err)
{
    if (err != null)
    {
        // Load Error.
        Debug.LogErrorFormat("Load Error!, code={0}, message={1}", err.Code.ToString(), err.Message);
        return;
    }
    
    // DB & Load success.

    //-----------------------------------//
    // Asset Load.
    //-----------------------------------//

    // Asset Load処理完了後、OctoSettings の Unload Allをfalseにしている場合、
    // IAssetOperatorを使ってUnloadもできます
    //（※非同期Loadを行っている場合はタイミングにご注意下さい）
    // OctoManager.UnloadAssetBundle と同等の操作を内部で行います
    // opr.Unload();
}

// Callback成功後、AssetBundleが不要になったタイミングにてUnloadする場合
// (IAssetOperator.Unload と同等の操作)
//OctoManager.UnloadAssetBundle("AssetBundle名");

```

### AssetBundleのUnload

LoadしたAssetBundleは、オクト内部で管理しています。<br>

```
OctoManager.LoadAssetBundle は（LoadされていなければLoad後）参照カウントをプラスし、
OctoManager.UnloadAssetBundle、もしくは IAssetOperator.Unload で、参照カウントをマイナスしています。
０になったらオクト内部で管理しているAssetBundleをUnloadしています。
```
**`OctoManager.LoadAssetBundle` が成功したら、必ず `OctoManager.UnloadAssetBundle` or `IAssetOperator.Unload` を呼んで下さい。**<br>

<br>
**!!! 注意 !!!**<br>
Unload を呼ぶタイミングと回数にご注意下さい。<br>
OctoSettings の Unload Allを`true`にしている場合、<br>
すでにAssetBundleからロードしていたオブジェクトも含めて破棄されます。<br>
また、Loadが成功した数だけUnloadを呼ばないと、参照カウントが残ってしまい、**AssetBundleがUnloadされません。**<br>

### LoadのCancel

`OctoManager.LoadAssetBundle` を呼ぶと、リクエストIDが返ってきます。<br>
これを使って、ロードのキャンセルを行うことが出来ます。<br>

```cs
int requestId = OctoManager.LoadAssetBundle("AssetBundle名", OnComplete);

// Cancel.
if(OctoManager.CancelLoadingAssetBundle(requestId)==true)
{
    // Cancel Success.
}

// OctoManager.LoadAssetBundle で指定したコールバック
void OnComplete(IAssetOperator opr, LoadError err)
{
    if (err != null)
    {
        // Load Error.
        // ※キャンセルの場合もエラーが返ってきます（err.code==LoadErrorCode.LoadCancel）
        return;
    }
    
    // Load Success.
}

```

`LoadAssetBundle` が完了する（コールバックが帰ってくる）前にキャンセルを呼ぶと、<br>
即座にキャンセル扱いとなり、コールバックを返します。<br>
（内部的には、既にダウンロード中の処理は中断しません）<br>
<br>
**!!! 注意 !!!**<br>
キャンセルが成功した場合、参照カウントがマイナスされるので、**Unload は呼ばないで下さい。**<br>
キャンセルが失敗した場合（リクエストIDが不正、既にロード完了後、など）は、<br>
Unload されていないので、 **Unloadを必ず呼んで下さい。**

## AssetLoaderについて

単一のAssetBundleのLoad/Unload処理、及びAssetのLoadをシンプルに取り扱うためのクラスです。<br>
１クラスにつき１つのAssetBundleの管理を行います（使い回し不可）。<br>
`MonoBehaiviour`を継承しており、このクラスが削除される際にUnloadが自動的に呼ばれるため、Unloadの独自管理をしたい場合は不向きです。<br>
<br>
他、使用方法は[AssetLoader.md](Docs/AssetLoader.md)を参照して下さい。

## Cachingについて

キャシングを操作する場合は、<br>
`OctoManager.Caching`I/Fを使用して下さい。<br>
OctoSettingsで選択したキャッシング（Caching Type）を操作できます。<br>
また、オクトの独自Cachingを使用する場合、**AssetBundle以外の素材も取り扱う事が出来ます**。<br>

| CachingType    | 説明              |
|----------------|-------------------|
| UnityDefault   | Unityのキャッシング |
| OctoAutoDelete | オクトの独自キャッシング<br>起動時にキャッシュが指定サイズ（初期値:1GB）を超えていたら、最終使用日時が古いものから削除します（指定サイズを下回るまで削除します） |
| OctoFullCache  | オクトの独自キャッシング<br>キャッシュの自動削除は行いません。 |

詳細は[Caching.md](Docs/Caching.md)を参照して下さい。<br>

## Errorについて

エラーの種類、及びエラーコードについては[ErrorCodes.md](Docs/ErrorCodes.md)を参照して下さい。<br>

## ローカルDBについて

オクトでは、全てのAssetBundleなどの情報を各クライアントのローカルにDBとして保存しています。
この詳しい仕様については、[こちら](Docs/Database.md)をご覧ください。

