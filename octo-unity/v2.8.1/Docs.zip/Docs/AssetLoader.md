# AssetLoader

## index
* [AssetLoaderとは](#assetloaderとは)
* [AssetLoaderの使い方](#assetloaderの使い方)
* [Inspector上での設定方法](#inspector上での設定方法)
* [ソース上での使用方法](#ソース上での使用方法)
* [ErrorCodeについて](#errorcodeについて)
* [使用上の注意点](#使用上の注意点)
* [内部処理](#内部処理)
 - [Setupについて](#setupについて)
 - [LoadAssetの内部処理について](#loadassetの内部処理について)
 - [実際と違う型を指定してしまった場合](#実際と違う型を指定してしまった場合)
 - [AssetBundleのUnload及びCancelタイミングについて](#assetbundleのunload及びcancelタイミングについて)



## AssetLoaderとは
単一のAssetBundle のLoad/Unload処理、及びAssetのLoadをシンプルに取り扱うためのクラスです。<br>
１クラスにつき１つのAssetBundleの管理を行います（使い回し不可）。<br>
<br>
※`MonoBehaiviour`を継承しており、このクラスが削除される際にUnloadが自動的に呼ばれるため、Unloadの独自管理をしたい場合は不向きです。<br>
オブジェクトのLoadからUnloadまで一元管理するため、`OctoSettings.UnloadAll`の設定は`true`がオススメです。<br>
参考：[AssetBundle.Unload(true)](http://docs.unity3d.com/ja/current/ScriptReference/AssetBundle.Unload.html)

## AssetLoaderの使い方
AssetLoader の使い方は、大きく分けて下記の２つ。<br>
使い手がやり易い方を選択して使用して下さい。

 - Inspector上で予めLoadしたい情報を設定しておき、自動Loadする方法（[→詳細](#inspector上での設定方法)）
 - ソース上で AddComponent し、メソッドを呼び出して手動Loadする方法（[→詳細](#ソース上での使用方法)）

## Inspector上での設定方法

![inspector_sample](images/asset_loader_inspector_1.png)

- `Asset Bundle Name`<br>
ロードするAssetBundle名

- `Auto Load`<br>
自動的にロードするか（falseであれば、アクティブであってもロードしません）

- `Request Asset Data`<br>
明示的にロード設定するAsset情報、及びLoad処理終了時に呼ばれるイベントを指定できます<br>
→この配列が空（size=0）であれば、AssetBundleロード完了後に<br>
　内部で`IAssetOperator.LoadAsset<T>()`が呼ばれます（後述の【Asset名指定無しのLoad/Get】参照））

- `[Low Level] LoadAssetBundle complete.`<br>
AssetBundle がロード完了した時点で呼ばれるイベントを指定できます（Low Level.）<br>

- （Inspector表示補足）`Loaded/Loading Assets`<br>
AssetLoaderにて現在管理しているAsset名と（LoadAsset をリクエストしたAsset名）、<br>
各LoadStatus の一覧を確認できます。<br>
【LoadStatus説明】<br>
　・BeforeLoad, Loading ： ロード終了前<br>
　・Loaded ： ロード成功<br>
　・Fail ： ロード失敗<br>

## ソース上での使用方法

- Setup（最初に呼ぶメソッド）<br>
```cs
public bool Setup(AssetBundle名)
```

- Assetのロード（AssetBundleのロードも行います）<br>

```cs
void AssetLoder.LoadAsset<T>(Asset名, ロード完了時のAction);
```

ex.

```cs
AssetLoader _loader;

_loader = gameObject.AddComponent<AssetLoader>();
_loader.Setup("hogehoge");
// Asset = GameObjectの場合
_loader.LoadAsset<GameObject>("hoge_asset_name", onLoadAssetComplete);

void onLoadAssetComplete(GameObject obj, LoadError error)
{
     if (error != null)
     {
         // Load Error.
         return;
     }
     // Instantiate 処理
}
```

- 既にLoad済みのAsset取得

```cs
// ロード済みでなければnullが返ってくる
T asset = AssetLoader.GetAsset<T>(Asset名);
```

- Asset名指定無しのLoad/Get<br>
AssetBundleに内包されているAssetが一つの場合に使用出来ます。<br>
Load時には内部で `IAssetOperator.LoadAsset<T>()`を呼んでいます（引数無しの LoadAsset）。<br>
複数Assetを内包しておらず、シンプルにAssetを扱う際にオススメです。

```cs
T AssetLoder.LoadAsset<T>(ロード完了時のAction);

// 引数無し - ロードしたAssetが一つの場合、もしくは AssetLoader.LoadAsset<T>() でロード済みのAssetを取得する
T AssetLoader.GetAsset<T>();
```

- AssetBundleのロード完了後に呼ばれるイベント指定（Low Level）<br>
AssetBundle がロード完了した時点で呼ばれるイベントを指定できます。<br>
必要であれば、LoadAsset を実行する前に呼んで下さい。<br>

```cs
void AssetLoader.SetCompleteLoadAssetBundle(UnityAction<IAssetOperator, LoadError> onComplete);
```

## ErrorCodeについて

`AssetLoader.LoadAsset` のコールバックにて、エラーが返ってくることがあります。<br>
エラーの種類は下記の通りです。<br>

* AssetBundleをLoadする時のエラー<br>
　→ `OctoManager.LoadAssetBundle`内部でのエラー（[ErrorCode.md](Docs/ErrorCode.md)を参照）<br>
　→ LoadがCancelされた時のエラー：*LoadErrorCode.LoadCancel*<br>
* AssetをLoadする時のエラー<br>
　→ Asset名が不正/存在しないAsset：*AssetLoaderErrorCode.AssetLoaderIncorrectName*<br>
　→ 無事Load出来たが、指定している型が違う：*AssetLoaderErrorCode.AssetLoaderTypeDiffered*<br>

他、エラーコードの詳細については[ErrorCode.md](Docs/ErrorCode.md)を参照して下さい。

## 使用上の注意点
`OctoManager.LoadAssetBundle` / `OctoManager.UnloadAssetBundle` は内部で呼んでいるため、<br>
AssetLoader を使う場合は上記メソッドは外部で呼ばないで下さい。

## 内部処理

内部処理の説明です。<br>
以下は見なくても実装出来ますが、実装時のヒントや、拡張・ソース改修時用にどうぞ。

### Setupについて

`AssetLoader.Setup`は、<br>
`AssetLoader.LoadAsset` 実行時にLoadするAssetBundle名を予め指定するメソッドです。
Inspector 上からも指定できます。

### LoadAssetの内部処理について

AssetBundle名が指定されていれば（Setupが呼ばれていれば）、`AssetLoader.LoadAsset`を呼ぶタイミングは自由です。<br>
<br>
AssetBundleがロードされていなければロードし、完了後Assetをロードしています。<br>
ロードしたAssetについてはAssetLoader内部で保持しているので、<br>
指定したAssetが既にロード済みであれば、**すぐにコールバックが返って来ます。**<br>
（もしAssetBundleのロードに失敗してしまった場合は、次の`AssetLoader.LoadAsset`処理時にリトライします）

### 実際と違う型を指定してしまった場合

実際と違う型を指定してしまった場合、`AssetLoader.LoadAsset<T>`にて、<br>
*AssetLoaderErrorCode.AssetLoaderTypeDiffered* が返ってきます。<br>
（[ErrorCodeについて](#errorcodeについて)参照）

ex.

```cs
AssetLoader _loader;

//---------
// Setup.
//---------

// hoge = GameObject（Texture2Dではない）
_loader.LoadAsset<Texture2D>("hoge", onComplete);

void onComplete(Texture2D obj, LoadError error)
{
    if (error != null)
    {
        // error.
        if(error.Code==AssetLoaderErrorCode.AssetLoaderTypeDiffered)
        {
            //---------
            // ＊型が違っている場合に何か処理をしたいのであればここで
            //---------
            Debug.Log(error.Message); // hoge is type differed - Actual Type[UnityEngine.GameObject] (Parameter Type[UnityEngine.Texture2D])
        }
        return;
    }
    
    // success.
}
```

【ワンポイントアドバイス】<br>
もし、AssetBundle/Asset名は分かっても、Loadするまで型が分からない場合は、<br>
基本クラスである`UnityEngine.Object`で型指定してLoadしてくれば、型違いのエラーは出ません。<br>

ex.

```cs
//LoadAssetにおける、一番の基本クラス - UnityEngine.Object で型指定してLoad
_loader.LoadAsset<UnityEngine.Object>("hoge", onComplete);

void onComplete(UnityEngine.Object obj, LoadError error)
{
   // これなら error.Code == AssetLoaderErrorCode.AssetLoaderTypeDiffered になる事は無い
   
   // 各処理
}
```


### AssetBundleのUnload及びCancelタイミングについて

AssetBundle の Unload/Cancel は、AssetLoader が破棄されるタイミングで（`MonoBehaviour.OnDestory`）呼ばれます。<br>
使い回し不可のシンプルなクラスのため、外部から直接呼び出せないようになっています。<br>
<br>
AssetBundleのLoad処理中であればCancel（`OctoManager.CancelLoadAssetBundle`）が呼ばれ、<br>
既にLoad済みの場合はUnload（`OctoManager.UnloadAssetBundle`）が呼ばれます。<br>



